<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('convertToBase64')){
	function check_password_strength($password){
	
		$uppercase = preg_match('@[A-Z]@', $password);
		$lowercase = preg_match('@[a-z]@', $password);
		$number    = preg_match('@[0-9]@', $password);
		$specialChars = preg_match('@[^\w]@', $password);

		if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) <6) {
			//echo 'Password should be at least 6 characters in length and should include at least one upper case letter, one number, and one special character.';
			return 0;
		}else{
			//echo 'Strong password.';
			return 1;
		}
	}
}

if (!function_exists('addrecapta')){
	function addrecapta(){
		return "<div class='g-recaptcha' data-sitekey='6LdDf7oUAAAAAMllaRQ4hYzIVc0iQ9SuuNdaEbul'></div>";
	}
}
if (!function_exists('verifyrecapta')){
	function verifyrecapta($response){
		$secret = '6LdDf7oUAAAAAN4o7jQ4H24JIdVgq1vq7YlrVDR7';
		$jsonurl = 'https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$response;
		$json = file_get_contents($jsonurl, 0, null, null);
		$json_output = json_decode($json, true);
		
		return $json_output['success'];
	}
}

if (!function_exists('send_email_codeigniter')){
	function send_email_codeigniter($sendfrom, $sendfromname, $replyto, $replytoname, $toemail, $subject, $message){
		$ci =& get_instance();
		$ci->load->helper('email');
		$ci->load->library('email');
		//SMTP & mail configuration
			$config = array(
				'protocol'  => 'smtp',
				'smtp_host' => 'mail.bebettergte.org',
				'smtp_port' => 587,
				'smtp_user' => 'thebridge@bebettergte.org',
				'smtp_pass' => 'bridge2019@#',
				//'mailtype'  => 'html',
				'validation'  => TRUE,
				//'charset'   => 'utf-8',
				'newline'   => '\r\n'
			);
			$ci->email->initialize($config);
			$ci->email->set_mailtype("html");
			$ci->email->set_newline("\r\n");
			
			$ci->email->from($sendfrom, $sendfromname); 
			$ci->email->reply_to($replyto, $replytoname);
			$ci->email->to($toemail);
			$ci->email->subject($subject); 
			$ci->email->message($message);
			
			if($ci->email->send()){
				return 1;
			}else{ 
				return 0;
			}
	}
}

if (!function_exists('send_email_phpmailer')){
	function send_email_phpmailer($sendfrom, $sendfromname, $replyto, $replytoname, $toemail, $subject, $message){
		$ci =& get_instance();
		$ci->load->helper('email');
		$ci->load->library('email');
		
			$ci->load->library('phpmailer_lib');
			$mail = $ci->phpmailer_lib->load();
			
			// SMTP configuration
			$mail->isSMTP();
			$mail->Host     = 'email-smtp.eu-west-1.amazonaws.com';
			$mail->SMTPAuth = true;
			$mail->Username = 'AKIAU26TFZAZRZAMXI56';
			$mail->Password = 'BPgKSTouY8u1+ou6Nz8tUyYONViHqYDS2roFSikvJf9A';
			$mail->SMTPSecure = 'tls';
			$mail->Port     = 587;
			
			$mail->setFrom($sendfrom, $sendfromname);
			$mail->addReplyTo($replyto, $replytoname);
			
			// Add a recipient
			$mail->addAddress($toemail);
			
			// Add cc or bcc 
			//$mail->addCC('teesoftent@gmail.com');
			//$mail->addBCC('bcc@example.com');
			
			// Email subject
			$mail->Subject = $subject;
			
			// Set email format to HTML
			$mail->isHTML(true);
			
			// Email body content
			$mail->Body = $message;
			
			if($mail->send()){
				return 1;
			}else{ 
				return 0;
			}
	}
}

if (!function_exists('encrypt_decrypt')){
	function encrypt_decrypt($action, $string) {
		$output = false;
		$encrypt_method = "AES-256-CBC";
		$secret_key = md5('GOBUY8743673467');
		$secret_iv = md5('7324563246');
		// hash
		$key = hash('sha256', $secret_key);
		
		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		if ( $action == 'encrypt' ) {
			$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
			$output = base64_encode($output);
		} else if( $action == 'decrypt' ) {
			$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
		}
		return $output;
	}
}

if (!function_exists('generate_password')){
	function generate_password(){
		$alp = "ABCDEFGHJKLMNPQRSTUVWXYZ"; $alp2 = "abcdefghijkmnpqrstuvwxyz"; $pass="";
		$ff = rand(1,4); $fs = rand(5,8);

		for ($k=1; $k<=8; $k++){
			if ($k==$ff or $k==$fs){ 
				$pass=$pass.rand(1,9);
			}else{
				$wch = rand(1,2);
				if ($wch==2) $pass=$pass.substr($alp, rand(1,23), 1);
				if ($wch==1) $pass=$pass.substr($alp2, rand(1,24), 1);
			}
		}
		return $pass;
	}
}

if (!function_exists('gen_dept_up')){
	function gen_dept_up($type){
		$CI =& get_instance(); $CI->load->database();
		
		$myuname = $type.rand(111111, 999999);
		$query = $CI->db->get_where('users', array('username' => $myuname), 1);
		if ($query->num_rows() > 0) { $myuname = gen_dept_up($type); }
		return $myuname;
	}
}

if (!function_exists('processing_fees')){
	function processing_fees($total){
		$pfees = 0;
		if ($total<2500){ $pfees = (1.5/100) * $total; }
		else{
			$pfees = ((1.5/100) * $total) + 100;
			if ($pfees>2000){ $pfees = 2000; }
		}
		
		return $pfees;
	}
}
	