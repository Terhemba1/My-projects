<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 JP Graph library
 */

class JPgraph
{
    public function __construct(){
        log_message('Debug', 'JP Graph class is loaded.');
    }

    public function load(){
        // Include PHPMailer library files
        require_once APPPATH.'third_party/JPgraph/jpgraph.php';
		
        
        //$dompdf = new Dompdf();
        //return $dompdf;
    }
}