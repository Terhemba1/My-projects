<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {
	
	function __construct() { 
         parent::__construct();
		 $this->load->model('settings_model');
		 $this->load->model('state_model');
		 $this->load->model('admin_model');
		 $this->load->helper('form');
		 $this->load->library('form_validation');
		 $this->load->helper('email');
		 $this->load->library('email');
		 $this->load->helper('all_functions');
		 
    }
	
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "home"; $data['myhome'] = 1;
		
		//$this->load->view('user/p_header', $data);
		$this->load->view('home/index', $data);
		//$this->load->view('user/p_footer', $data);
	}
	
	/*login, reset password start */
	
	public function login_process(){
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('passcode', 'Pass Code', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$data = array(
				'username' => $this->input->post('username'), 
				'passcode' => md5($this->input->post('passcode'))
			);
			$query = $this->db->get_where('users', $data, 1);
			$result['users'] = $query->result();
			if ($query->num_rows() == 0) { $data['error'] = 2; }
			else{
				if ($result['users'][0]->status == 0){ $data['error'] = 3; }
				else{
					$sessprefix = $this->config->item('sess_prefix');
					
					set_cookie($sessprefix.'user_id', $result['users'][0]->id, @time()+(24*60*60));
					set_cookie($sessprefix.'user_name', $result['users'][0]->username, @time()+(24*60*60));
					set_cookie($sessprefix.'user_urname', $result['users'][0]->name, @time()+(24*60*60));
					set_cookie($sessprefix.'user_passcode', $result['users'][0]->passcode, @time()+(24*60*60));
					set_cookie($sessprefix.'user_type', $result['users'][0]->type, @time()+(24*60*60));
					//set_cookie($sessprefix.'user_dept', $result['users'][0]->dept, @time()+(24*60*60));
					
					$this->admin_model->update_record($result['users'][0]->id, array('last_login' => @time()));
					if ($result['users'][0]->type == 'RO') redirect('user/mykpireport/index');
					else redirect('user/panel/index');
				}
			}
		}
		$data['settings'] = $this->settings_model->getSettings();
		 $data['page'] = "signin";
		
		//$this->load->view('user/p_header', $data);
		$this->load->view('user/index', $data);
		//$this->load->view('user/p_footer', $data);
	}
	
	public function logout(){
		$sessprefix = $this->config->item('sess_prefix');
		delete_cookie($sessprefix.'user_id'); delete_cookie($sessprefix.'user_name'); delete_cookie($sessprefix.'user_dept');
		delete_cookie($sessprefix.'user_passcode'); delete_cookie($sessprefix.'user_type');
		
		redirect('user/index/logout1');
	}
	
	public function logout1(){
		
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 4;  $data['page'] = "signin";
		
		//$this->load->view('user/p_header', $data);
		$this->load->view('user/index', $data);
		//$this->load->view('user/p_footer', $data);
	}
	
	public function no_permission(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 5; $data['page'] = "signin";
		
		//$this->load->view('user/p_header', $data);
		$this->load->view('user/index', $data);
		//$this->load->view('user/p_footer', $data);
	}
	
	public function forget_username(){
		$data = array(); $passres = $this->uri->segment('4');
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "email";
		if (isset($passres)){ if ($passres=='done'){ $data['error'] = 9; }else{ $data['error'] = 0; } }
		$data['page'] = "signin";
		
		$this->load->view('user/p_header', $data);
		$this->load->view('user/forget_username', $data);
		$this->load->view('user/p_footer', $data);
	}
	
	public function forget_username_email(){
		$this->form_validation->set_rules('loginUserEmail', 'Email Address', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('members', array('email' => $this->input->post('loginUserEmail')), 1);
			if ($query->num_rows() == 0) { $data['error'] = 2; }
			else{
				$result['users'] = $query->result(); $accid = $result['users'][0]->id; $email = $result['users'][0]->email; $username = $result['users'][0]->username;
				//$frgpasscode = encrypt_decrypt('encrypt', $accid.'-'.(@time() + (24*60*60)));
				//$this->members_model->update_record($accid, array('forgetpassword' => $frgpasscode));
				
				$query = $this->db->get('settings');
				$result['settings2'] = $query->result();
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
				
				$to_email = $this->input->post('loginUserEmail');
				$subject = "Your Username - ".$result['settings2'][0]->appowner; 
							
				$emaildata['message'] = "Hello, your username is <b>$username</b>";
				//$emaildata['link'] = site_url('user/index/reset_my_password/'.$frgpasscode); $emaildata['link_name'] = "RESET MY PASSWORD";
				$emaildata['settings'] = $this->settings_model->getSettings();
				$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
										
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
										
				send_email_codeigniter($appemail, $appname, 'no-reply@solutionideaforum.com', 'No-Reply', $to_email, $subject, $message);
				//send_email_phpmailer($appemail, $appname, 'no-reply@solutionideaforum.com', 'No-Reply', $to_email, $subject, $message);
				
				$data['error'] = 3;
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "signin";
		
		$this->load->view('user/p_header', $data);
		$this->load->view('user/forget_username', $data);
		$this->load->view('user/p_footer', $data);
	}
	
	public function recover_password(){
		$data = array(); $passres = $this->uri->segment('4');
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "email";
		if (isset($passres)){ if ($passres=='done'){ $data['error'] = 9; }else{ $data['error'] = 0; } }
		$data['page'] = "signin";
		
		$this->load->view('user/p_header', $data);
		$this->load->view('user/reset_password', $data);
		$this->load->view('user/p_footer', $data);
	}
	
	public function reset_password_email(){
		$this->form_validation->set_rules('loginUserEmail', 'Email Address', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('members', array('email' => $this->input->post('loginUserEmail')), 1);
			if ($query->num_rows() == 0) { $data['error'] = 2; }
			else{
				$result['users'] = $query->result(); $accid = $result['users'][0]->id; $email = $result['users'][0]->email; $username = $result['users'][0]->username;
				$frgpasscode = encrypt_decrypt('encrypt', $accid.'-'.(@time() + (24*60*60)));
				$this->members_model->update_record($accid, array('forgetpassword' => $frgpasscode));
				
				$query = $this->db->get('settings');
				$result['settings2'] = $query->result();
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
				
				$to_email = $this->input->post('loginUserEmail');
				$subject = "Password Reset Link - ".$result['settings2'][0]->appowner; 
										
				$emaildata['message'] = "Hello <b>$username</b>, Please click the below button to reset your password".
				"<br>{note this link expires in 24 hours}";
				$emaildata['link'] = site_url('user/index/reset_my_password/'.$frgpasscode); $emaildata['link_name'] = "RESET MY PASSWORD";
				$emaildata['settings'] = $this->settings_model->getSettings();
				$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
										
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
										
				send_email_codeigniter($appemail, $appname, 'no-reply@solutionideaforum.com', 'No-Reply', $to_email, $subject, $message);
				//send_email_phpmailer($appemail, $appname, 'no-reply@solutionideaforum.com', 'No-Reply', $to_email, $subject, $message);
				
				$data['error'] = 3;
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "signin";
		
		$this->load->view('user/p_header', $data);
		$this->load->view('user/reset_password', $data);
		$this->load->view('user/p_footer', $data);
	}
	
	public function reset_my_password(){
		$data = array();
		$resetcode = encrypt_decrypt('decrypt', $this->uri->segment('4'));
		if (!isset($resetcode)){ $data['page'] = "email"; }
		else{
			$resetcodebrk = @explode('-', $resetcode);
			$query = $this->db->get_where('members', array('id' => $resetcodebrk[0]), 1);
			if ($query->num_rows() == 0) { $data['error'] = 4; $data['page'] = "email"; }
			else{
				if (@time() > $resetcodebrk[1]){ $data['error'] = 5; $data['page'] = "email"; }
				else{
					$data['error'] = 0; $data['page'] = "new"; $data['link'] = $this->uri->segment('4');
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "signin";
		
		$this->load->view('user/p_header', $data);
		$this->load->view('user/reset_password', $data);
		$this->load->view('user/p_footer', $data);
	}
	
	public function reset_password_new(){
		$this->form_validation->set_rules('new_password', 'new password', 'required');
		//$this->form_validation->set_rules('password_meterV', 'password meter', 'required');
		$this->form_validation->set_rules('confrim_password', 'confirm password', 'required');
		//$this->form_validation->set_rules('conf_meterV', 'confirm meter', 'required');
		$resetcode = encrypt_decrypt('decrypt', $this->uri->segment('4')); 
		
		$data = array(); $data['link'] = $this->uri->segment('4');
		if (!isset($resetcode)){ $data['page'] = "email"; }
		else{
			$resetcodebrk = @explode('-', $resetcode);
			$query = $this->db->get_where('members', array('id' => $resetcodebrk[0]), 1);
			if ($query->num_rows() == 0) { $data['error'] = 4; $data['page'] = "email"; }
			else{
				$result['users'] = $query->result(); $accid = $result['users'][0]->id; $email = $result['users'][0]->email; $username = $result['users'][0]->username;
				if (@time() > $resetcodebrk[1]){ $data['error'] = 5; $data['page'] = "email"; }
				else{
					if ($this->form_validation->run() == FALSE) { $data['error'] = 6; $data['page'] = "new"; }
					else{
						/*if ($this->input->post('password_meterV') < 50) { $data['error'] = 7; $data['page'] = "new"; }
						else{*/
							if ($this->input->post('new_password') != $this->input->post('confrim_password')) { $data['error'] = 8; $data['page'] = "new"; }
							else{
								$newpass = md5($this->input->post('new_password'));
								$this->members_model->update_record($accid, array('forgetpassword' => '', 'password' => $newpass));
								
								$query = $this->db->get('settings');
								$result['settings2'] = $query->result();
								$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
								
								$to_email = $email;
								$subject = "Your Password Reset Successfully - ".$result['settings2'][0]->appowner; 
														
								$emaildata['message'] = "Hello <b> $username</b>, Your password was reset successfully";
								$emaildata['settings'] = $this->settings_model->getSettings();
								$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
														
								$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
														
								send_email_codeigniter($appemail, $appname, 'no-reply@solutionideaforum.com', 'No-Reply', $to_email, $subject, $message);
								//send_email_phpmailer($appemail, $appname, 'no-reply@solutionideaforum.com', 'No-Reply', $to_email, $subject, $message);
				
								redirect('user/index/recover_password/done');
							}
						//}
					}
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "signin";
		
		$this->load->view('user/p_header', $data);
		$this->load->view('user/reset_password', $data);
		$this->load->view('user/p_footer', $data);
	}
	/*login, reset password start */
	
}
