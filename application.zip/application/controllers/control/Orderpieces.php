<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class orderpieces extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('products_model');
		$this->load->model('location_model');
		$this->load->model('order_model');
		$this->load->model('cart_model');
		$this->load->model('clients_model');
		$this->load->model('productsales_model');
		$this->load->model('admin_model');
		$this->load->model('stock_model');
		$this->load->model('sales_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "orderpieces"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "orderpieces"; $data['whattodo'] = "add";
		$data['location'] = $this->location_model->get_all_record();
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('email', 'email', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('clients', array('email' => $this->input->post('email')));
			   $result['clients'] = $query->result(); 
			  
			$result['category'] = $query->result();  
			if ($query->num_rows() > 0){ $data['error'] = 2; 
			 $clientid = $result['clients'][0]->id;
			//$this->session->set_userdata('existedclient', $this->input->post('email'));
			redirect('control/orderpieces/add_view/'.$clientid.'/exist');
			}
			else{
			
				$datainsert = array(
					'name' => $this->input->post('name'),
					'email' => $this->input->post('email'),
					'phone' => $this->input->post('phone'),
					'agent' => $this->input->post('agent'),
					'datetime' => @time(),
					'status' => 1
				);
				
				$last_id = $this->clients_model->insert_record($datainsert);
				$pass = @uniqid();
				$email= $this->input->post('email');
				$name= $this->input->post('name');
				//id, email, first_name, other_name, password, clearance, last_login, status, created_on, activationcode, frgpasswordcode, distributorid
				}
				
				 $from = "info@bebetterbooks.biz"; // my Email address. Put one there
       $to = strip_tags("$email"); //  Email address from the form

        //Email subject
        $subject = "Be Better Books";
        
        //Add HTML contents in $message
       $emaildata['message'] = "<b>Greetings  ".$name.", </b><br> Thank you for chosing Triple J and J.<br> We appreciate your patronage";
	   $emaildata['settings'] = $this->settings_model->getSettings();
	   $message = $this->load->view('email_template/email_contact1.php', $emaildata, TRUE);
send_email_phpmailer($from, $subject, $from, 'Be Better Books', $to, $subject, $message);
				
				
				 //$data['error'] = 10;
				
				redirect('control/orderpieces/add_view/'.$last_id.'/addednew');
			
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "orderpieces"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	
	
	
	public function add_cart(){
		$clientid = $this->input->post('clientid');
		 $proid =  $this->input->post('proid');
		$this->form_validation->set_rules('proid', 'proid', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('cart', array('proid' => $this->input->post('proid'),'customerid' => $clientid));
			   $result['cart'] = $query->result(); 
			if ($query->num_rows() > 0){ //$data['error'] = 2; 
			 $cartid = $result['cart'][0]->id;
			  $cartquantity = $result['cart'][0]->quantity;
			  $newquantity = $cartquantity + $this->input->post('quantity');
			  $cartprice = $result['cart'][0]->totalprice;
			  $newcartprice = $newquantity * $this->input->post('cost');
			  $title= $this->input->post('name');
			   $category= $this->input->post('category');
			   $receiptno = $result['cart'][0]->receiptno;
			  
			   
			   $datas = array(
							'quantity' => $newquantity,
							'totalprice' => $newcartprice
							
							  );
			    $this->cart_model->update_record($cartid, $datas);
			//$this->session->set_userdata('existedclient', $this->input->post('email'));
			redirect('control/orderpieces/add_view/addednew/'.$clientid.'?action=add&code='.$receiptno);
			}
			else{
				$receiptno = $this->input->post('receiptno');
				$totalprice = $this->input->post('quantity') * $this->input->post('cost') ;
			//id, title, category, quantity, unitprice, totalprice, proid, customerid
				$datainsert = array(
					'title' => $this->input->post('name'),
					'category' => $this->input->post('category'),
					'quantity' => $this->input->post('quantity'),
					'unitprice' => $this->input->post('cost'),
					'customerid' => $clientid,
					'totalprice' => $totalprice,
					'receiptno' => $receiptno,
					'datetime' => time(),
					'proid' =>  $this->input->post('proid')
				);
				
				$last_id = $this->cart_model->insert_record($datainsert);
				//$pass = @uniqid();
				
				 //$data['error'] = 10;
				
				redirect('control/orderpieces/add_view/addednew/'.$clientid.'?action=add&code='.$receiptno);
			
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "orderpieces"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	}
	
	
	
	
	
		
	public function pay(){
		$receiptno = $_GET["code"];
		$clientid = $receiptno;
			if($this->input->post('address')){$address = $this->input->post('address');}else {$address="";}
			if($this->input->post('amount')){$amount = $this->input->post('amount');}else {$amount="";}
		$salesid = rand(1234,9876).'_'.rand(1000000,9999999);
		 $proid =  $this->input->post('proid');
		  $loyalty =  $this->input->post('discount');
		  //$loyaltyrate =  $this->input->post('loyaltyrate');
		$this->form_validation->set_rules('totalamount', 'totalamount', 'required');
		$this->form_validation->set_rules('allquantity', 'allquantity', 'required');
		
		$data = array();
	
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 71; }
		else{
			//$this->session->set_userdata('address', $address);
			 // $this->session->set_userdata('amount', $amount);
			 $this->session->set_userdata('receipt', $receiptno);
			  $this->session->set_userdata('clientid', $clientid);
			$num = $this->input->post('num');
			//$distributor = $this->input->get('dis');
			for($i=1; $i<=$num; $i++){
				$productid = $this->input->post('product'.$i);
				$unitquantity = $this->input->post('unitquantity'.$i);
				
				 $query = $this->db->query("update product set total2=total2-".$unitquantity." where id='".$productid."'");
				
				 $datasales = array(
					'receiptno' => $receiptno,
					'productid' => $productid,
					'clientid' => $clientid,
					'unitquantity' => $unitquantity,
					'loyalty' => $loyalty,
					//'location' => $this->input->post('loc'),
					//'delivery' => $this->input->post('delivery'),
					//'pay_mode' => $this->input->post('mode'),
					//'address' => $address,
					//'amount' => $amount,
					'datetime' => time()
				);
				 $this->sales_model->insert_record($datasales);
				 
				
				 
				  $datad = array(
					'ds_ID' => $salesid,
					'pro_ID' => $productid,
					'dsp_stock' => $unitquantity,
					'receiptno' => $receiptno
				);
				  $this->productsales_model->insert_record($datad);
				}
				
				
				
				$totalamount = $this->input->post('totalamount');
				$t = (int)($totalamount) - (int)($loyalty);
				$datain = array(
					'ds_ID' => $salesid,
					//'d_ID' => $distributor,
					'ds_type' => "sales",
					'ds_tamt' => $this->input->post('totalamount'),
					'ds_com' => $loyalty,
					'ds_remit' => $t,
					'ds_time' => time(),
					//'loc_ID' =>  $this->input->post('loc'),
					'receiptno' => $receiptno
				);
				$this->stock_model->insert_record($datain);
				
				
					$email = "atsaamj@gmail.com";
					$name =	$this->input->post('name');
					
					
					//orderpieces email
					
					$totalamount = $this->input->post('totalamount');
					//$newloyalty = ($this->input->post('loyaltyrate')/100)* $t;
					$topay = $totalamount- (int)($loyalty);
					 $this->session->set_userdata('topay', $topay);
					  $this->session->set_userdata('totalamount', $totalamount);
					    $this->session->set_userdata('loyalty', @$loyalty);

				
			
			
		$query = $this->db->get_where('users', array('status' => 3));
			   $result['users'] = $query->result(); 
			if ($query->num_rows() > 0){ //$data['error'] = 2; 
			 $stemail = $result['users'][0]->email;	
			
			 $from = "info@bebetterbooks.biz"; // my Email address. Put one there
       $to = strip_tags("$email"); //  Email address from the form

        //Email subject
        $subject = "Triple J & J Fabrics and Footwears";
        
        //Add HTML contents in $message
       $emaildata['message'] = "<b>Greetings  MD Triple J & J Fabrics and Footwears, </b><br> There is an orderpieces with a successful payment from the shop. <br> Below is the details";
	 
	 $emaildata['settings'] = $this->settings_model->getSettings();
	   $message = $this->load->view('email_template/receipt2.php', $emaildata, TRUE);
send_email_phpmailer($from, $subject, $from, 'Triple J & J Fabrics and Footwears', $to, $subject, $message);   
			}
			//$query = $this->db->query("update cart set mode = '".$this->input->post('mode')."', oldloyalty = '$loyal' where receiptno = '$receiptno'");
			//$query = $this->db->query("update clients set loyalty = '$newloyalty', oldloyalty = '$loyal' where id = '$clientid'");
	 $query = $this->db->query("insert into cart_parm select * from cart where receiptno='$receiptno'");
	$this->db->delete('cart', array('receiptno' => $receiptno));
				
				redirect('control/orderpieces/add_view/addednew?paid=done');
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "orderpieces"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	public function remove_cart(){
		$data = array();  //$quesID = $this->uri->segment('5');
		$clientid = $this->uri->segment('5');
		if ($_GET["c"]){
			$pid = $_GET["c"]; $code = $_GET["code"];
			$this->db->delete('cart', array('proid' => $pid));
			//redirect('control/orderpieces/add_view/'.$clientid.'/addednew?action=add&code='.$code);
			redirect('control/orderpieces/add_view/addednew/'.$code.'?action=add&code='.$code);
		}
		
		//$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "orderpieces"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	
	
		public function delete(){
		$data = array();  //$quesID = $this->uri->segment('5');
		$clientid = $this->uri->segment('5');
		//if ($_GET["code"]){
			$pid = $_GET["code"];
			$this->db->delete('cart', array('customerid' => $clientid));
			redirect('control/orderpieces/add_view/addednew/'.$clientid.'?action=add&code='.$clientid);
		//}
		
		//$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "orderpieces"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/orderpieces', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	
	
	
	
	
	
	
	
	/* change enable and disable status start */
	
	
	
}
