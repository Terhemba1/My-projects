<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('admin_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array(); $sessprefix = $this->config->item('sess_prefix');
		$data['settings'] = $this->settings_model->getSettings();
		$query = $this->db->get_where("users", array("id" => $this->session->userdata($sessprefix.'admin_user_id')));
		$data['profile'] = $query->row();
		
		$data['error'] = 0; $data['page'] = "profile";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/profile', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function update(){
		$this->form_validation->set_rules('yemail', 'Email Address', 'required');
		$this->form_validation->set_rules('yfname', 'First name', 'required');
		$this->form_validation->set_rules('yoname', 'Other Names', 'required');
		$sessprefix = $this->config->item('sess_prefix');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) {
			$data['error'] = 1;
		}else{
			$query = $this->db->get_where('users', array('email' => $this->input->post('yemail'), 'id!=' => $this->session->userdata($sessprefix.'admin_user_id')));
			$result['users'] = $query->result();
			if ($query->num_rows() > 0) {
				$data['error'] = 2;
			}else{
				$dataupdate = array(
					'email' => $this->input->post('yemail'), 
					'first_name' => $this->input->post('yfname'),
					'other_name' => $this->input->post('yoname')
				);
				$this->admin_model->update_record($this->session->userdata($sessprefix.'admin_user_id'), $dataupdate);
				$this->session->set_userdata($sessprefix.'admin_user_email', $this->input->post('yemail'));
				$this->session->set_userdata($sessprefix.'admin_user_fname', $this->input->post('yfname'));
				
				$data['error'] = 3;
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$query = $this->db->get_where("users", array("id" => $this->session->userdata($sessprefix.'admin_user_id')));
		$data['profile'] = $query->row();
		$data['page'] = "profile";
				
		$this->load->view('control/p_header', $data);
		$this->load->view('control/profile', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function password_update(){
		$this->form_validation->set_rules('c_pass', 'Current Password', 'required');
		$this->form_validation->set_rules('n_pass', 'New Password', 'required');
		$this->form_validation->set_rules('cf_pass', 'Confirm Password', 'required');
		$sessprefix = $this->config->item('sess_prefix');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) {
			$data['error'] = 4; 
		}else{
			if (md5($this->input->post('c_pass')) != $this->session->userdata($sessprefix.'admin_user_password')){
				$data['error'] = 5;
			}else{
				if (check_password_strength($this->input->post('n_pass')) == 0) {
					$data['error'] = 6;
				}else{
					if ($this->input->post('n_pass') != $this->input->post('cf_pass')) {
						$data['error'] = 7;
					}else{
						$dataupdate = array('password' => md5($this->input->post('n_pass')));
						$this->admin_model->update_record($this->session->userdata($sessprefix.'admin_user_id'), $dataupdate);
						$this->session->set_userdata($sessprefix.'admin_user_password', md5($this->input->post('n_pass')));
						
						$data['error'] = 8;
					}
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$query = $this->db->get_where("users", array("id" => $this->session->userdata($sessprefix.'admin_user_id')));
		$data['profile'] = $query->row(); $data['page'] = "profile";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/profile', $data);
		$this->load->view('control/p_footer', $data);
		
	}
	
}
