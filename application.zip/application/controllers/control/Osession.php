<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Osession extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('state_model');
		$this->load->model('osession_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "osession"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	//access: index.php/control/osession/cronjobendsession
	public function cronjobendsession(){
		$query = $this->db->query("select * from session where status=1 and end<".@time()." ORDER BY end LIMIT 100");
		if ($query->num_rows() > 0){
			foreach ($query->result_array() as $row){ 
				$sessionID = $row['id'];
				$this->db->where('id', $sessionID)->update('session', array('status' => 3));
				$this->db->where('session', $sessionID)->update('evelutorlist', array('conno' => ''));				
			}
		}
		
	}
	
	/* add new start */
	public function add_view(){
		$data = array(); $newstatus = $this->uri->segment('5');
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "osession"; $data['whattodo'] = "add";
		if ($newstatus == 'sremoved'){ $data['ADerror'] = 1; }
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function add_process(){
		$organizationID = $this->uri->segment('4');
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('sdate', 'edate', 'required');
		$this->form_validation->set_rules('edate', 'edate', 'required');
		$this->form_validation->set_rules('desc', 'desc', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE){ $data['error'] = 1; }
		else{
			$startdate = @strtotime($this->input->post('sdate')); $enddate = @strtotime($this->input->post('edate'));
			$query = $this->db->get_where('session', array('status!=' =>  3, 'status!=' =>  4, 'title' =>  $this->input->post('title'), 'organization' => $organizationID, 'start' => $startdate, 'end' => $enddate)); 
			
				$result['session'] = $query->result();
				if ($query->num_rows() > 0){ $data['error'] = 2; }
				else{
					$randnumber = 3156124182;
					$query = $this->db->query("select * from session"); $mysessionid = $randnumber + $query->num_rows() + 1;
					$datainsert = array(
						'id' => $mysessionid,
						'organization' => $organizationID,
						'title' => $this->input->post('title'),
						'description' => $this->input->post('desc'),
						'start' => $startdate,
						'end' => $enddate,
						'status' => 0,
						'datetime' => @time()
					);
					
					$last_id = $this->osession_model->insert_record($datainsert);
					redirect('control/osession/edit_view/'.$organizationID.'/'.$mysessionid.'/new');
				}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "osession"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
		
	}
	
	/* add new end */
	
	/* edit start */
	public function edit_view(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5'); $newstatus = $this->uri->segment('6');
		$query = $this->db->get_where("session", array("id" => $sessionID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'ueval'){ $data['errorS'] = 1; $data['error'] = 0; }
		elseif ($newstatus == 'reset'){ $data['error'] = 9; }else{ $data['error'] = 0; }
		$data['page'] = "osession"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5'); 
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('sdate', 'edate', 'required');
		$this->form_validation->set_rules('edate', 'edate', 'required');
		$this->form_validation->set_rules('desc', 'desc', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 5; }
		else{
			$startdate = @strtotime($this->input->post('sdate')); $enddate = @strtotime($this->input->post('edate'));
			$query = $this->db->get_where('session', array('id!=' => $sessionID, 'status!=' =>  3, 'status!=' =>  4, 'title' =>  $this->input->post('title'), 'organization' => $organizationID, 'start' => $startdate, 'end' => $enddate)); 
			$result['session'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 6; }
			else{
				$datainsert = array(
					'organization' => $organizationID,
					'title' => $this->input->post('title'),
					'description' => $this->input->post('desc'),
					'start' => $startdate,
					'end' => $enddate
				);
				
				$this->osession_model->update_record($sessionID, $datainsert);
				$data['error'] = 7;
			}
		}
		
		$query = $this->db->get_where("session", array("id" => $sessionID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "osession"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function updatevalue(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		$coll = "";
		if ($this->input->post('tnumvalue') > 0){
			if ($this->input->get('w')=='v'){
				$this->db->delete('svalue', array('session' => $sessionID, 'type' => $this->input->get('manage'))); 
				$this->db->delete('squestion', array('session' => $sessionID, 'type' => $this->input->get('manage'))); 
			}elseif ($this->input->get('w')=='l'){
				$this->db->delete('slca', array('session' => $sessionID, 'type' => $this->input->get('manage'))); 
				$this->db->delete('slquestion', array('session' => $sessionID, 'type' => $this->input->get('manage'))); 
			}
			for ($i=0; $i<$this->input->post('tnumvalue'); $i++){
				$quessel = 0;
				for ($j=0; $j<$this->input->post('tnumques'.$i); $j++){
					if ($this->input->post('eques'.$i.$j)){
						if ($this->input->get('w')=='v'){
							$svqid = "SVQ_V".$organizationID.$sessionID.$this->input->post('evalue'.$i).$this->input->post('eques'.$i.$j);
							$datainsert = array(
								'id' => $svqid, 
								'session' => $sessionID, 
								'type' => $this->input->get('manage'), 
								'value' => $this->input->post('evalue'.$i), 
								'question' => $this->input->post('eques'.$i.$j)
							);
							$this->db->insert('squestion', $datainsert);
						}elseif ($this->input->get('w')=='l'){
							$svqid = "SVQ_L".$organizationID.$sessionID.$this->input->post('evalue'.$i).$this->input->post('eques'.$i.$j);
							$datainsert = array(
								'id' => $svqid, 
								'session' => $sessionID, 
								'type' => $this->input->get('manage'), 
								'lca' => $this->input->post('evalue'.$i), 
								'question' => $this->input->post('eques'.$i.$j)
							);
							$this->db->insert('slquestion', $datainsert);
						}
						
						$quessel++;
					}
				}
				if ($quessel>0){
					if ($this->input->get('w')=='v'){
						$svid = "SV_V".$organizationID.$sessionID.$this->input->post('evalue'.$i);
						$datainsert = array(
							'id' => $svid,
							'organization' => $organizationID, 
							'session' => $sessionID, 
							'type' => $this->input->get('manage'), 
							'value' => $this->input->post('evalue'.$i)
						);
						$this->db->insert('svalue', $datainsert);
					}elseif ($this->input->get('w')=='l'){
						$svid = "SV_L".$organizationID.$sessionID.$this->input->post('evalue'.$i);
						$datainsert = array(
							'id' => $svid,
							'organization' => $organizationID, 
							'session' => $sessionID, 
							'type' => $this->input->get('manage'), 
							'lca' => $this->input->post('evalue'.$i)
						);
						$this->db->insert('slca', $datainsert);
					}
				}
			}
			//$data['errorMSG'] = $coll;
			if ($this->input->get('w')=='v'){ redirect('control/osession/edit_view/'.$organizationID.'/'.$sessionID.'/ueval?manage='.$this->input->get('manage').'&w=v#manage'); }
			elseif ($this->input->get('w')=='l'){ redirect('control/osession/edit_view/'.$organizationID.'/'.$sessionID.'/ueval?manage='.$this->input->get('manage').'&w=l#manage'); }
		}
		
		$query = $this->db->get_where("session", array("id" => $sessionID)); $data['records'] = $query->row();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "osession"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function remove(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		
		if ($sessionID){
			$query = $this->db->get_where("session", array("id" => $sessionID));
			if ($query->num_rows() > 0){
				$this->db->delete('svalue', array('session' => $sessionID));
				$this->db->delete('squestion', array('session' => $sessionID));
				$this->osession_model->update_record($sessionID, array('status' => 4));
				redirect('control/osession/add_view/'.$organizationID.'/sremoved');
			}
		}
		
		$query = $this->db->get_where("session", array("id" => $sessionID)); $data['records'] = $query->row();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "osession"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/*public function ajaxtest(){
		$response = new stdClass;
		for ($i=0; $i<=1000000; $i++){
			
		}
		$response->status1 = "1";
		$response->status2 = "2";
		die(json_encode($response));
	}*/
	
	public function pausesession(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		
		$data['error'] = 0; $data['page'] = "osession"; 
		if ($sessionID){
			$query = $this->db->get_where("session", array("id" => $sessionID, "status!=" => 4));
			if ($query->num_rows() > 0){
				$result['sessionrecord'] = $query->result();
				
				if ($result['sessionrecord'][0]->status == 1){
					
					//update session status=2
					$this->db->where('id', $sessionID)->update('session', array('status' => 2));
					$_GET['error'] = 5;
				
				}else{ $_GET['error'] = 1; }
				
			}else{ $_GET['error'] = 1; }
		}else{ $_GET['error'] = 1; }
		
		$query = $this->db->get_where("session", array("id" => $sessionID)); $data['records'] = $query->row();
		$data['settings'] = $this->settings_model->getSettings();
		$data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function endsession(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		
		$data['error'] = 0; $data['page'] = "osession"; 
		if ($sessionID){
			$query = $this->db->get_where("session", array("id" => $sessionID, "status!=" => 4));
			if ($query->num_rows() > 0){
				$result['sessionrecord'] = $query->result();
				
				if ($result['sessionrecord'][0]->status == 1 or $result['sessionrecord'][0]->status == 2){
					//update session status=2
					$this->db->where('id', $sessionID)->update('session', array('status' => 3));
					$this->db->where('session', $sessionID)->update('evelutorlist', array('conno' => ''));
					$_GET['error'] = 6;
				
				}else{ $_GET['error'] = 1; }
			}else{ $_GET['error'] = 1; }
		}else{ $_GET['error'] = 1; }
		
		$query = $this->db->get_where("session", array("id" => $sessionID)); $data['records'] = $query->row();
		$data['settings'] = $this->settings_model->getSettings();
		$data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function activatesession(){
		$response = new stdClass;
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		$query = $this->db->get_where("organization", array("id"=>$organizationID)); $result['organizationrecord'] = $query->result();
		//$this->uri->segment('4'); $query = $this->db->get_where("session", array("id"=>$sessionID)); $result['sessionrecord'] = $query->result();
		
		if ($sessionID){
			$query = $this->db->get_where("session", array("id" => $sessionID, "status!=" => 4));
			if ($query->num_rows() > 0){
				$result['sessionrecord'] = $query->result();
				
				if ($result['sessionrecord'][0]->status == 0){
					$tquescount = $this->db->get_where('squestion', array('session' => $sessionID))->num_rows() + 0;
					$evcount = $this->db->get_where('staff', array('status' => 1, 'organization' => $organizationID))->num_rows() + 0;
					//$tquescount =0; $evcount =0;
					if ($tquescount > 0 and $evcount > 0){
						//update session status=1
						$this->db->where('id', $sessionID)->update('session', array('status' => 1));
						
						//generate evaluator and save to evaluatorlist
						//$extra = " and id NOT IN (select staff from evelutorlist where session='".$sessionID."') ";
						$query = $this->db->query("select * from staff where status='1' and organization='".$organizationID."' and id IN (select evaluator from evaluator) ORDER BY datetime ASC");
						$numberofstaff = $query->num_rows();
						foreach ($query->result_array() as $row){
							$thisid = $sessionID.$row['id']; $thisconno = md5($thisid); $passcode = generate_password();
							$datainsert = array(
								'id' => $thisid,
								'session' => $sessionID,
								'staff' => $row['id'],
								'passcode' => md5($passcode),
								'conno' => $thisconno,
								'status' => 1,
								'datetime' => @time(),
								'organization' => $organizationID
							);
							$this->db->insert('evelutorlist', $datainsert);
							
							//send email to evaluator
							$myemail = $row['email']; $myname = $row['name'];
							
							$query = $this->db->get('settings'); $result['settings2'] = $query->result();
							$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
							
							$subject = "Evaluation Invitation by ".$result['organizationrecord'][0]->name." - ".$result['settings2'][0]->appowner; 
							
							$emaildata['message'] = "You are cordially invited by <b>".$result['organizationrecord'][0]->name."</b> to participate in an evaluation".
							" <b>'".$result['sessionrecord'][0]->title."'</b> with the following details: <br><br> Passcode: <b>$passcode</b> ".
							"<br>Access Link: <a href='".site_url('user/evaluation/index/'.$sessionID.'/'.$row['id'].'')."'>".site_url('user/evaluation/index/'.$sessionID.'/'.$row['id'].'')."</a>".
							"<br><br>Use the link and input your passcode to access the evaluation page.<br><b>Best Regards</b>";
							
							$emaildata['first_name'] = $myname; //$emaildata['link'] = site_url('index.php/control/index'); $emaildata['link_name'] = "ADMIN LOGIN PAGE"; 
							$emaildata['settings'] = $this->settings_model->getSettings();
							$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
												
							send_email_phpmailer($appemail, $appname, $appemail, $appname, $myemail, $subject, $message);
							//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
						}
						
						if ($numberofstaff > 0){ $SAerror = 4; }else{ $SAerror = 3; }
					}else{ $SAerror = 2; }
				}else{ $SAerror = 1; }
				
			}else{ $SAerror = 1; }
		}else{ $SAerror = 1; }
		
		$response->status1 = $SAerror;
		//$response->status2 = $numberofstaff;
		die(json_encode($response));
	}
	
	public function reactivatesession(){
		$response = new stdClass;
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		$query = $this->db->get_where("organization", array("id"=>$organizationID)); $result['organizationrecord'] = $query->result();
		//$this->uri->segment('4'); $query = $this->db->get_where("session", array("id"=>$sessionID)); $result['sessionrecord'] = $query->result();
		
		if ($sessionID){
			$query = $this->db->get_where("session", array("id" => $sessionID, "status!=" => 4));
			if ($query->num_rows() > 0){
				$result['sessionrecord'] = $query->result();
				
				if ($result['sessionrecord'][0]->status == 2){
					$tquescount = $this->db->get_where('squestion', array('session' => $sessionID))->num_rows() + 0;
					$evcount = $this->db->get_where('staff', array('status' => 1, 'organization' => $organizationID))->num_rows() + 0;
					//$tquescount =0; $evcount =0;
					if ($tquescount > 0 and $evcount > 0){
						//update session status=1
						$this->db->where('id', $sessionID)->update('session', array('status' => 1));
						
						//generate evaluator and save to evaluatorlist
						$extra = " and id NOT IN (select staff from evelutorlist where session='".$sessionID."') ";
						$query = $this->db->query("select * from staff where status='1' and organization='".$organizationID."' and id IN (select evaluator from evaluator) $extra ORDER BY datetime ASC");
						$numberofstaff = $query->num_rows();
						foreach ($query->result_array() as $row){
							$thisid = $sessionID.$row['id']; $thisconno = md5($thisid); $passcode = generate_password();
							$datainsert = array(
								'id' => $thisid,
								'session' => $sessionID,
								'staff' => $row['id'],
								'passcode' => md5($passcode),
								'conno' => $thisconno,
								'status' => 1,
								'datetime' => @time(),
								'organization' => $organizationID
							);
							$this->db->insert('evelutorlist', $datainsert);
							
							//send email to evaluator
							$myemail = $row['email']; $myname = $row['name'];
							
							$query = $this->db->get('settings'); $result['settings2'] = $query->result();
							$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
							
							$subject = "Evaluation Invitation by ".$result['organizationrecord'][0]->name." - ".$result['settings2'][0]->appowner; 
							
							$emaildata['message'] = "You are cordially invited by <b>".$result['organizationrecord'][0]->name."</b> to participate in an evaluation".
							" <b>'".$result['sessionrecord'][0]->title."'</b> with the following details: <br><br> Passcode: <b>$passcode</b> ".
							"<br>Access Link: <a href='".site_url('user/evaluation/index/'.$sessionID.'/'.$row['id'].'')."'>".site_url('user/evaluation/index/'.$sessionID.'/'.$row['id'].'')."</a>".
							"<br><br>Use the link and input your passcode to access the evaluation page.<br><b>Best Regards</b>";
							
							$emaildata['first_name'] = $myname; //$emaildata['link'] = site_url('index.php/control/index'); $emaildata['link_name'] = "ADMIN LOGIN PAGE"; 
							$emaildata['settings'] = $this->settings_model->getSettings();
							$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
												
							send_email_phpmailer($appemail, $appname, $appemail, $appname, $myemail, $subject, $message);
							//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
						}
						
						if ($numberofstaff > 0){ $SAerror = 8; }else{ $SAerror = 7; }
					}else{ $SAerror = 2; }
				}else{ $SAerror = 1; }
				
			}else{ $SAerror = 1; }
		}else{ $SAerror = 1; }
		
		$response->status1 = $SAerror;
		//$response->status2 = $numberofstaff;
		die(json_encode($response));
	}
	
	/* edit new end */
	
	/*public function disable_process(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		
		$this->osession_model->update_record($sessionID, array('status' => '0')); $data['ADerror'] = 1;
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "osession"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		
		$this->osession_model->update_record($sessionID, array('status' => '1')); $data['ADerror'] = 2;
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "osession"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/osession', $data);
		$this->load->view('control/p_footer', $data);
	}*/
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

		$organizationID = $this->uri->segment('4');
        $total_record = $this->osession_model->total_record($organizationID);
		$categories = $this->osession_model->get_record($length, $start, $organizationID);
		
		$data = array();
        foreach($categories->result() as $r){
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }
			elseif ($r->status==2){ $status = "<span class='label label-primary'>paused</span>"; }
			elseif ($r->status==3){ $status = "<span class='label label-info'>ended</span>"; }
			else{ $status = "<span class='label label-warning'>inactive</span>"; }
			
			//$query = $this->db->get_where('dept', array('id' =>  $r->dept)); $result['dept'] = $query->result();
			//$query = $this->db->get_where('role', array('id' =>  $r->role)); $result['role'] = $query->result();
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/osession/edit_view/".$organizationID."/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-sm btn-default'><i class='fa fa-gear'></i> Manage</a>";
			if ($r->status==0) $links .= "<a href='".site_url('index.php/control/osession/remove/'.$organizationID.'/'.$r->id)."' class='btn btn-sm btn-danger' onClick='javascript:return confirm(\"Are sure you want to remove $r->id [$r->title]?\")'><i class='fa fa-times'></i> Remove</a>";
			//else $links .= "<a href='".site_url('index.php/control/osession/enable_process/'.$organizationID.'/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->email [$r->name]?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div></td>";
			
			$data[] = array(
				"$status | <font size=4><b>".$r->id."</b></font>",
				"<b>".$r->title."</b>",
				"".@date('M d, Y', $r->start)."",
				"".@date('M d, Y', $r->end)."",
				$links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
