<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->model('admin_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('category_model');
		$this->load->helper("all_functions");
		$this->load->helper('email');
		$this->load->library('email');
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "admin"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "admin"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('admin_email', 'Email Address', 'required');
		$this->form_validation->set_rules('admin_fname', 'First Name', 'required');
		$this->form_validation->set_rules('admin_oname', 'Other Names', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('users', array('email' => $this->input->post('admin_email')));
			$result['admin'] = $query->result();
			if ($query->num_rows() > 0) { $data['error'] = 2; }
			else{
				$newpass = generate_password(); $encnewpass = md5($newpass);
				if ($this->input->post('admin_cls') == 'supper'){ $cls = "AD";  }else{ $cls = "AS"; }
				$datainsert = array(
					'email' => $this->input->post('admin_email'), 
					'first_name' => $this->input->post('admin_fname'), 
					'other_name' => $this->input->post('admin_oname'), 
					'password' => $encnewpass, 
					'clearance' => $cls, 
					'last_login' => 0, 
					'status' => 1, 
					'created_on' => @time(), 
					'activationcode' => '', 
					'frgpasswordcode' => ''
				);
				
				$last_id = $this->admin_model->insert_record($datainsert);
				
				$adminemail = $this->input->post('admin_email'); $adminfname = $this->input->post('admin_fname');
				
				$query = $this->db->get('settings');
				$result['settings2'] = $query->result();
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
				
				$subject = $result['settings2'][0]->appowner." - New ADMIN Account Login Details"; 
										
				$emaildata['message'] = "Welcome!!!<br> An ADMIN account was created for you on $appname, find below your login details and button to login page".
				"<br>Login Email Address: <b>$adminemail</b><br> Login Password: <b>$newpass</b>";
				$emaildata['link'] = site_url('index.php/control/index'); $emaildata['link_name'] = "ADMIN LOGIN PAGE"; $emaildata['first_name'] = $adminfname;
				$emaildata['settings'] = $this->settings_model->getSettings();
				$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
									
				send_email_phpmailer($appemail, $appname, $appemail, $appname, $adminemail, $subject, $message);
				//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				
				redirect('control/admin/edit_view/'.$last_id.'/new');
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "admin"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* add new category end */
	
	/* edit new category start */
	public function edit_view(){
		$data = array();
		$adminID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("users", array("id" => $adminID));
        $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus=='new'){ $data['error'] = 1; }elseif ($newstatus=='reset'){ $data['error'] = 9; }else{ $data['error'] = 0; }
		$data['page'] = "admin"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function edit_process(){
		$adminID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('admin_email', 'Email Address', 'required');
		$this->form_validation->set_rules('admin_fname', 'First Name', 'required');
		$this->form_validation->set_rules('admin_oname', 'Other Names', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 4; }
		else{
			$query = $this->db->get_where('users', array('email' => $this->input->post('admin_email'), 'id!=' => $adminID));
			$result['admin'] = $query->result();
			if ($query->num_rows() > 0) { $data['error'] = 5; }
			else{
				if ($this->input->post('admin_cls') == 'supper'){ $cls = "AD";  }else{ $cls = "AS"; }
				$datainsert = array(
					'email' => $this->input->post('admin_email'), 
					'first_name' => $this->input->post('admin_fname'), 
					'other_name' => $this->input->post('admin_oname'), 
					'clearance' => $cls
				);
				$this->admin_model->update_record($adminID, $datainsert);
				$data['error'] = 6;
			}
		}
		
		$query = $this->db->get_where("users", array("id" => $adminID));
        $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "admin"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new category end */
	
	/* change enable and disable status start */
	public function disable_process(){
		$data = array();
		$adminID = $this->uri->segment('4');
		
		$query = $this->db->get_where('users', array('id' => $adminID));
		$result['admin'] = $query->result();
		if ($result['admin'][0]->clearance == 'AD') { $data['ADerror'] = 3; }
		else{
			$this->admin_model->update_record($adminID, array('status' => '0')); $data['ADerror'] = 1;
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "admin"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array();
		$adminID = $this->uri->segment('4');
		
		$query = $this->db->get_where('users', array('id' => $adminID));
		$result['admin'] = $query->result();
		if ($result['admin'][0]->clearance == 'AD') { $data['ADerror'] = 3; }
		else{
			$this->admin_model->update_record($adminID, array('status' => '1')); $data['ADerror'] = 2;
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "admin"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* change enable and disable status start */
	
	/* reset password start */
	public function password_reset(){
		$data = array();
		$adminID = $this->uri->segment('4');
		
		$query = $this->db->get_where('users', array('id' => $adminID));
		$result['admin'] = $query->result(); $data['records'] = $query->row();
		if ($result['admin'][0]->clearance == 'AD') { $data['error'] = 3; }
		else{
			//$data['error'] = 0;
			//$this->admin_model->update_record($adminID, array('status' => '1')); $data['ADerror'] = 2;
			$newpass = generate_password(); $encnewpass = md5($newpass);
			$this->admin_model->update_record($adminID, array('password' => $encnewpass));
				
			$adminemail = $result['admin'][0]->email; $adminfname = $result['admin'][0]->first_name;
				
			$query = $this->db->get('settings');
			$result['settings2'] = $query->result();
			$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
				
			$subject = $result['settings2'][0]->appowner." - ADMIN Account Password Reset"; 
										
			$emaildata['message'] = "Yes!!!<br> Your ADMIN account password was reset for by a <b>SUPPER ADMIN</b>".
				"<br>Login Email Address: <b>$adminemail</b><br> Login Password: <b>$newpass</b>";
				$emaildata['link'] = site_url('index.php/control/index'); $emaildata['link_name'] = "ADMIN LOGIN PAGE"; $emaildata['first_name'] = $adminfname;
				$emaildata['settings'] = $this->settings_model->getSettings();
				$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
									
				send_email_phpmailer($appemail, $appname, $appemail, $appname, $adminemail, $subject, $message);
				//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				
				redirect('control/admin/edit_view/'.$adminID.'/reset');
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "admin"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/admin', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* reset password start */
	
	public function admin_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

        $total_record = $this->admin_model->total_record();
		$categories = $this->admin_model->get_record($length, $start);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			$links = "";
			if ($r->clearance != 'AD'){
				$links = "<td class='text-center'><div class='btn-group'>".
				"<a href='index.php/control/admin/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
				if ($r->status==1) $links .= "<a href='".site_url('index.php/control/admin/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->email [$r->first_name $r->other_name]?\")'><i class='fa fa-times'></i> deactivate</a>";
				else $links .= "<a href='".site_url('index.php/control/admin/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->email [$r->first_name $r->other_name]?\")'><i class='fa fa-check'></i> activate</a>";
				$links .= "</div></td>";
			}
			$data[] = array(
				"<td><b>".$r->email."</b></td>",
                "<td><b>".$r->first_name."</b> ".$r->other_name."</td>",
                $links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
