<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Expenses extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('Expenses_model');
		$this->load->model('expenses_model');
		$this->load->model('admin_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "expenses"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	
	
	
	
	
	
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "expenses"; $data['whattodo'] = "add";
		//$data['location'] = $this->location_model->get_all_record();
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('amount', 'amount', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			
				$datainserts = array(
					'reason' => $this->input->post('reason'),
					'amount' => $this->input->post('amount'),
					'datetime' => @time(),
					'status' => 1
					
				);
			if	($this->expenses_model->insert_record($datainserts)){$data['error'] = 10;}
				
				redirect('index.php/control/expenses/add_view?added=1');
			
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "expenses"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	

	
	/* add new category end */
	
	/* edit new category start */
	public function edit_view(){
		$data = array();
		$valueID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("users", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'qnew'){ $data['errorT'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'removed'){ $data['errorT'] = 4; $data['error'] = 0; }else{ $data['error'] = 0; }
		$data['page'] = "expenses"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $data = array(); $valueID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('email', 'email', 'required');
			if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			
				$pass = @uniqid();
				//id, email, first_name, other_name, password, clearance, last_login, status, created_on, activationcode, frgpasswordcode, distributorid
				$fname = $this->input->post('fname');
					$lname = $this->input->post('lname');
					$email = $this->input->post('email');
					$phone = $this->input->post('phone');
					 $query = $this->db->query("update users set first_name = '$fname', other_name = '$lname', phone ='$phone', email='$email' where id = '$valueID'");

			if ($query)	{$data['error'] = 10;}
				
				
				
				
				 //$data['error'] = 10;
				
				redirect('control/expenses/add_view?updated=yes');
			}
		
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "expenses"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function arrange(){
		$data = array(); $valueID = $this->uri->segment('4'); 
		if ($this->input->get('q')){
			if ($this->input->get('up')){
				$query = $this->db->order_by('arrange', 'desc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange<' => $this->input->get('up'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('up')));
			
			}elseif($this->input->get('down')){
				$query = $this->db->order_by('arrange', 'asc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange>' => $this->input->get('down'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('down')));
				
			}
			redirect('control/expenses/edit_view/'.$valueID.'#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "expenses"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new category end */
	
	/* change enable and disable status start */
	
	public function remove(){
		$data = array(); $valueID = $this->uri->segment('4'); $quesID = $this->uri->segment('5'); 
		if ($quesID){
			$this->db->where('id', $quesID)->update('lquestion', array('status' => 0));
			redirect('control/expenses/edit_view/'.$valueID.'/removed#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "expenses"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function disable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->admin_model->update_record($valueID, array('status' => '0'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 1; $data['page'] = "expenses"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->admin_model->update_record($valueID, array('status' => '1'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 2; $data['page'] = "expenses"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/expenses', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* change enable and disable status start */
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

        $total_record = $this->expenses_model->total_record();
		$categories = $this->expenses_model->get_record($length, $start);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1|| $r->status==2){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='control/expenses/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
			if ($r->status==1|| $r->status==2) $links .= "<a href='".site_url('control/expenses/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->amount?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('control/expenses/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->amount?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div>";
			
			$data[] = array(
                "$status <br><font size=4><b>".$r->reason."</b></font>",
				"<b>".$r->amount."</b>",
				"<b>".@date('M d, Y',$r->datetime)."</b>"
                //$links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
