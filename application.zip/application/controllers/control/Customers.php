<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('location_model');
		$this->load->model('customers_model');
		$this->load->model('admin_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "customers"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "customers"; $data['whattodo'] = "add";
		$data['location'] = $this->location_model->get_all_record();
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('distributor', 'distributor', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('agent', array('email' => $this->input->post('email'), 'distributor' => $this->input->post('distributor')));
			$result['category'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 2; }
			else{
			$id =	$this->input->post('distributor');
				 $query = $this->db->query("select * from distributor where d_ID='$id'");
											foreach ($query->result_array() as $row){
											$fname = $row['d_fname'];	
											$lname = $row['d_lname'];
											$email = $row['d_email'];
											$phone = $row['d_phone'];
											}
												
				//d_ID, d_fname, d_lname, d_email, d_phone, d_address, d_stamp, status, d_com, loc_ID
				$datainsert = array(
					'fname' => $fname,
					'lname' => $lname,
					'email' => $email,
					'phone' => $phone,
					'distributor' => $this->input->post('distributor'),
					'datetime' => @time(),
					'status' => 1
				);
				
				$this->customers_model->insert_record($datainsert);
				$pass = @uniqid();
				//id, email, first_name, other_name, password, clearance, last_login, status, created_on, activationcode, frgpasswordcode, distributorid
				$datainserts = array(
					'first_name' => $fname,
					'other_name' => $lname,
					'email' => $email,
					'phone' => $phone,
					'distributorid' => $this->input->post('distributor'),
					'created_on' => @time(),
					'clearance' => 'AD',
					'password' => md5($pass),
					'status' => 2
				);
			if	($this->admin_model->insert_record($datainserts)){$data['error'] = 10;}
				
				 $from = "info@bebetterbooks.biz"; // my Email address. Put one there
       $to = strip_tags("$email"); //  Email address from the form

        //Email subject
        $subject = "Learning Impact";
        
        //Add HTML contents in $message
       $emaildata['message'] = "<b>Greetings  ".$fname.", </b><br> Your account has been created  on our Be Better POS platform. Your  password  is ".$pass." Use the link below to login";
	   $emaildata['settings'] = $this->settings_model->getSettings();
	   $message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);
send_email_phpmailer($from, $subject, $from, 'Be Better POS', $to, $subject, $message);
				
				
				 //$data['error'] = 10;
				
				redirect('control/customers/add_view');
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "customers"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function question(){
		$data = array(); $data = array(); $valueID = $this->uri->segment('4');
		$this->form_validation->set_rules('question', 'question', 'required');
		$this->form_validation->set_rules('qtype', 'qtype', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['errorT'] = 1; }
		else{
			$good = "yes"; $scale = "";
			if ($this->input->post('qtype') == 'Likert Scale'){ 
				if ($this->input->post('qscale')){
					$brkscale = @explode(',', $this->input->post('qscale'));
					if (count($brkscale) > 1){ $scale = $this->input->post('qscale'); }else{ $good = "no"; }
				}else{ $good = "no"; }
			}
			if ($good == 'no') { $data['errorT'] = 5; }
			else{
				$query = $this->db->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'type' => $this->input->post('qtype'), 'question' => $this->input->post('question')));
				//$result['question'] = $query->result();
				if ($query->num_rows() > 0){ $data['errorT'] = 2; }
				else{
					$query = $this->db->get_where('lquestion', array('lca' => $valueID)); $numhave = $query->num_rows()+1;
					$datainsert = array(
						'lca' => $valueID,
						'type' => $this->input->post('qtype'),
						'question' => $this->input->post('question'),
						'scale' => $scale,
						'arrange' => $numhave,
						'status' => 1
					);
					
					$this->db->insert('lquestion', $datainsert);
					redirect('control/customers/edit_view/'.$valueID.'/qnew#stopques');
				}
			}
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "customers"; $data['whattodo'] = "edit"; $data['error'] = 0;
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* add new category end */
	
	/* edit new category start */
	public function edit_view(){
		$data = array();
		$valueID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("agent", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'qnew'){ $data['errorT'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'removed'){ $data['errorT'] = 4; $data['error'] = 0; }else{ $data['error'] = 0; }
		$data['page'] = "customers"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $data = array(); $valueID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('distributor', 'distributor', 'required');
			if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('agent', array('email' => $this->input->post('email'), 'distributor' => $this->input->post('distributor')));
			$result['category'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 2; }
			else{
			$id =	$this->input->post('distributor');
				 $query = $this->db->query("select * from distributor where d_ID='$id'");
											foreach ($query->result_array() as $row){
											$fname = $row['d_fname'];	
											$lname = $row['d_lname'];
											$email = $row['d_email'];
											$phone = $row['d_phone'];
											}
												
				//d_ID, d_fname, d_lname, d_email, d_phone, d_address, d_stamp, status, d_com, loc_ID
				$datainsert = array(
					'fname' => $fname,
					'lname' => $lname,
					'email' => $email,
					'phone' => $phone,
					'distributor' => $this->input->post('distributor'),
					'datetime' => @time(),
					'status' => 1
				);
				
				$this->customers_model->insert_record($datainsert);
				$pass = @uniqid();
				//id, email, first_name, other_name, password, clearance, last_login, status, created_on, activationcode, frgpasswordcode, distributorid
				$datainserts = array(
					'first_name' => $fname,
					'other_name' => $lname,
					'email' => $email,
					'phone' => $phone,
					'distributorid' => $this->input->post('distributor'),
					'status' => 2
				);
			if	($this->admin_model->insert_record($datainserts)){$data['error'] = 10;}
				
				 $from = " info@learningimpactmodel.com"; // my Email address. Put one there
       $to = strip_tags("$email"); //  Email address from the form

        //Email subject
        $subject = "Learning Impact";
        
        //Add HTML contents in $message
       $emaildata['message'] = "<b>Greetings  ".$fname.", </b><br> Your account has been created  on our Be Better POS platform. Your  password  is ".$pass." Use";
	   $emaildata['settings'] = $this->settings_model->getSettings();
	   $message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);
send_email_phpmailer($from, $subject, $from, 'Be Better POS', $to, $subject, $message);
				
				
				 //$data['error'] = 10;
				
				redirect('control/customers/add_view');
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "customers"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function arrange(){
		$data = array(); $valueID = $this->uri->segment('4'); 
		if ($this->input->get('q')){
			if ($this->input->get('up')){
				$query = $this->db->order_by('arrange', 'desc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange<' => $this->input->get('up'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('up')));
			
			}elseif($this->input->get('down')){
				$query = $this->db->order_by('arrange', 'asc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange>' => $this->input->get('down'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('down')));
				
			}
			redirect('control/customers/edit_view/'.$valueID.'#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "customers"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new category end */
	
	/* change enable and disable status start */
	
	public function remove(){
		$data = array(); $valueID = $this->uri->segment('4'); $quesID = $this->uri->segment('5'); 
		if ($quesID){
			$this->db->where('id', $quesID)->update('lquestion', array('status' => 0));
			redirect('control/customers/edit_view/'.$valueID.'/removed#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "customers"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function disable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->customers_model->update_record($valueID, array('status' => '0'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 1; $data['page'] = "customers"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->customers_model->update_record($valueID, array('status' => '1'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 2; $data['page'] = "customers"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/customers', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* change enable and disable status start */
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

        $total_record = $this->customers_model->total_record();
		$categories = $this->customers_model->get_record($length, $start);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$query = $this->db->get_where('agent', array('id' =>  $r->agent)); $result['agent'] = $query->result();
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/customers/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
			if ($r->status==1) $links .= "<a href='".site_url('index.php/control/customers/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->name?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('index.php/control/customers/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->name?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div>";
			
			$data[] = array(
                "<font size=4><b>".$r->name."</b></font>",
				"<b>".$r->email."</b>",
				"<b>".$r->phone."</b>",
				"<b>".$r->loyalty."</b>",
				"<b>".$result['agent'][0]->fname.' '.$result['agent'][0]->lname."</b>",
				"<b>".@date('M d,Y',$r->datetime)."</b>"
               // $links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
