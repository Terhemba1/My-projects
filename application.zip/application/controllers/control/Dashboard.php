<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->library('user_agent');
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "dashboard";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/dashboard', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* lock screen process start */
	public function lock_screen(){
		$data = array(); $sessprefix = $this->config->item('sess_prefix');
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "dashboard";
		
		if ($this->session->userdata($sessprefix.'admin_user_id')){
			$sessiondata = array(
				$sessprefix.'lock_admin_user_id' => $this->session->userdata($sessprefix.'admin_user_id'), 
				$sessprefix.'lock_admin_user_email' => $this->session->userdata($sessprefix.'admin_user_email'),
				$sessprefix.'lock_admin_user_fname' => $this->session->userdata($sessprefix.'admin_user_fname'),
				$sessprefix.'lock_admin_user_password' => $this->session->userdata($sessprefix.'admin_user_password'),
				$sessprefix.'lock_admin_user_clearance' => $this->session->userdata($sessprefix.'admin_user_clearance'),
				$sessprefix.'lock_admin_user_llogin' => $this->session->userdata($sessprefix.'admin_user_llogin'),
				$sessprefix.'lock_referrer' => $this->agent->referrer()
			);
			//$this->session->mark_as_temp($sessiondata, 3600);
			$this->session->set_userdata($sessiondata);
			$this->session->unset_userdata(array($sessprefix.'admin_user_id', $sessprefix.'admin_user_email', $sessprefix.'admin_user_fname', $sessprefix.'admin_user_password', $sessprefix.'admin_user_clearance'));
		}
		
		$this->load->view('control/lock_screen', $data);
	}
	public function lock_screen_login(){
		$this->form_validation->set_rules('lock_password', 'Password', 'required');
		$sessprefix = $this->config->item('sess_prefix');
		if ($this->form_validation->run() == FALSE) {
			$data = array(); 
			$data['settings'] = $this->settings_model->getSettings();
			$data['error'] = 1;
			
			$this->load->view('control/lock_screen', $data);
		}else{
			if (md5($this->input->post('lock_password')) != $this->session->userdata($sessprefix.'lock_admin_user_password')){
				$data = array();
				$data['settings'] = $this->settings_model->getSettings();
				$data['error'] = 2;
				
				$this->load->view('control/lock_screen', $data);
			}else{
				$sessiondata = array(
					$sessprefix.'admin_user_id' => $this->session->userdata($sessprefix.'lock_admin_user_id'), 
					$sessprefix.'admin_user_email' => $this->session->userdata($sessprefix.'lock_admin_user_email'),
					$sessprefix.'admin_user_fname' => $this->session->userdata($sessprefix.'lock_admin_user_fname'),
					$sessprefix.'admin_user_password' => $this->session->userdata($sessprefix.'lock_admin_user_password'),
					$sessprefix.'admin_user_clearance' => $this->session->userdata($sessprefix.'lock_admin_user_clearance'),
					$sessprefix.'admin_user_llogin' => $this->session->userdata($sessprefix.'lock_admin_user_llogin')
				);
				$this->session->set_userdata($sessiondata);
				$urltogoto = $this->session->userdata($sessprefix.'lock_referrer');
				$this->session->unset_userdata(array($sessprefix.'lock_admin_user_id', $sessprefix.'lock_admin_user_email', $sessprefix.'lock_admin_user_fname', $sessprefix.'lock_admin_user_password', $sessprefix.'lock_admin_user_clearance', $sessprefix.'lock_referrer'));
			
				redirect($urltogoto);
			}
		}
	}
	/* lock screen process end */
	
	public function no_permission(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 1; $data['page'] = "dashboard";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/dashboard', $data);
		$this->load->view('control/p_footer', $data);
	}
	
}
