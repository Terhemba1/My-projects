<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agents extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		//$this->load->model('location_model');
		$this->load->model('agents_model');
		$this->load->model('admin_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "agents"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	
	
	
	
	
	public function resetall(){
		
		 $query = $this->db->query("select * from users where status !='1' and status != '3'");
											foreach ($query->result_array() as $row){
												$email = $row['email'];
												$fname = $row['first_name'];
												$sname = $row['other_name'];
											 $passcode = generate_password();
											 $pass = md5($passcode);
										 $query = $this->db->query("update users set password= '$pass' where email = '$email'");
										  $from = "info@bebetterbooks.biz"; // my Email address. Put one there
       $to = strip_tags("$email"); //  Email address from the form

        //Email subject
        $subject = "Triple J & J Fabrics and Footwears New Password";
        
        //Add HTML contents in $message
       $emaildata['message'] = "<b>Greetings  ".$fname.' '.$sname.", </b><br> Your password has been reset successfully  on our Triple J & J Fabrics and Footwears platform. Your username is ".$email." and your new  password  is ".$passcode." Use the link below to login";
	   $emaildata['settings'] = $this->settings_model->getSettings();
	   $message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);
send_email_phpmailer($from, $subject, $from, 'Triple J & J Fabrics and Footwears', $to, $subject, $message);
										 
		}
	
	}
	
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "agents"; $data['whattodo'] = "add";
		//$data['location'] = $this->location_model->get_all_record();
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('email', 'email', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('users', array('email' => $this->input->post('email')));
			$result['category'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 2; }
			else{
			
				$pass = @uniqid();
				$fname = $this->input->post('fname');
				//id, email, first_name, other_name, password, clearance, last_login, status, created_on, activationcode, frgpasswordcode, distributorid, phone
				$datainserts = array(
					'first_name' => $this->input->post('fname'),
					'other_name' => $this->input->post('lname'),
					'email' => $this->input->post('email'),
					'phone' => $this->input->post('phone'),
					'created_on' => @time(),
					'clearance' => 'AD',
					'password' => md5($pass),
					'astatus' => 1,
					'status' => $this->input->post('type')
				);
			if	($this->admin_model->insert_record($datainserts)){$data['error'] = 10;}
				$email = $this->input->post('email');
				 $from = "info@bebetterbooks.biz"; // my Email address. Put one there
       $to = strip_tags("$email"); //  Email address from the form

        if($this->input->post('type') == '1'){
        $subject = "ForwardBenue2023 New Admin";} else{$subject = "ForwardBenue2023 New User";}
        
        //Add HTML contents in $message
       $emaildata['message'] = "<b>Greetings  ".$fname.", </b><br> Your account has been created  on our ForwardBenue2023 platform. Your  password  is ".$pass." Use the link below to login";
	   $emaildata['settings'] = $this->settings_model->getSettings();
	   $message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);
send_email_phpmailer($from, $subject, $from, 'ForwardBenue2023', $to, $subject, $message);
				
				
				 //$data['error'] = 10;
				
				redirect('control/agents/add_view?added=1');
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "agents"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	

	
	/* add new category end */
	
	/* edit new category start */
	public function edit_view(){
		$data = array();
		$valueID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("users", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'qnew'){ $data['errorT'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'removed'){ $data['errorT'] = 4; $data['error'] = 0; }else{ $data['error'] = 0; }
		$data['page'] = "agents"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $data = array(); $valueID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('email', 'email', 'required');
			if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			
				$pass = @uniqid();
				//id, email, first_name, other_name, password, clearance, last_login, status, created_on, activationcode, frgpasswordcode, distributorid
				$fname = $this->input->post('fname');
					$lname = $this->input->post('lname');
					$email = $this->input->post('email');
					$phone = $this->input->post('phone');
					 $query = $this->db->query("update users set first_name = '$fname', other_name = '$lname', phone ='$phone', email='$email' where id = '$valueID'");

			if ($query)	{$data['error'] = 10;}
				
				
				
				
				 //$data['error'] = 10;
				
				redirect('control/agents/add_view?updated=yes');
			}
		
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "agents"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function arrange(){
		$data = array(); $valueID = $this->uri->segment('4'); 
		if ($this->input->get('q')){
			if ($this->input->get('up')){
				$query = $this->db->order_by('arrange', 'desc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange<' => $this->input->get('up'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('up')));
			
			}elseif($this->input->get('down')){
				$query = $this->db->order_by('arrange', 'asc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange>' => $this->input->get('down'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('down')));
				
			}
			redirect('control/agents/edit_view/'.$valueID.'#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "agents"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new category end */
	
	/* change enable and disable status start */
	
	public function remove(){
		$data = array(); $valueID = $this->uri->segment('4'); $quesID = $this->uri->segment('5'); 
		if ($quesID){
			$this->db->where('id', $quesID)->update('lquestion', array('status' => 0));
			redirect('control/agents/edit_view/'.$valueID.'/removed#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "agents"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function disable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->admin_model->update_record($valueID, array('status' => '0'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 1; $data['page'] = "agents"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->admin_model->update_record($valueID, array('status' => '1'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 2; $data['page'] = "agents"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/agents', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* change enable and disable status start */
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

        $total_record = $this->admin_model->total_record();
		$categories = $this->admin_model->get_record($length, $start);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1|| $r->status==2){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='control/agents/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
			if ($r->status==1|| $r->status==2) $links .= "<a href='".site_url('control/agents/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->first_name?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('control/agents/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->first_name?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div>";
			
			$data[] = array(
                "$status <br><font size=4><b>".$r->first_name."</b></font>",
				"<b>".$r->email."</b>",
				"<b>".$r->phone."</b>",
                $links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
