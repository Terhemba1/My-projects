<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Organization extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('state_model');
		$this->load->model('organization_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "organization"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "organization"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function add_process(){
		$this->form_validation->set_rules('oname', 'oname', 'required');
		$this->form_validation->set_rules('oemail', 'oemail', 'required');
		$this->form_validation->set_rules('ophone', 'ophone', 'required');
		$this->form_validation->set_rules('oaddress', 'oaddress', 'required');
		$this->form_validation->set_rules('industry', 'industry', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE){ $data['error'] = 1; }
		else{
			$data['errorMSG'] = $_FILES['logo']['type'];
			if (!$_FILES['logo']['name']){ $data['error'] = 2; }
			else{
				$query = $this->db->get_where('organization', array('name' =>  $this->input->post('oname'), 'email' =>  $this->input->post('oemail'), 'phone' =>  $this->input->post('ophone'), 'industry' =>  $this->input->post('industry'))); 
				$result['organization'] = $query->result();
				if ($query->num_rows() > 0){ $data['error'] = 3; }
				else{
					$randnumber = 135682; $orgnumber = "";
					$query = $this->db->query("select * from organization order by id DESC LIMIT 1");
					if ($query->num_rows() > 0){ $result['organization'] = $query->result(); $orgnumber = "".($result['organization'][0]->id+$randnumber); }
					else{ $orgnumber = "".$randnumber; }
					
					$datainsert = array(
						'onumber' => $orgnumber,
						'passcode' => encrypt_decrypt('encrypt', generate_password()),
						'name' => $this->input->post('oname'),
						'email' => $this->input->post('oemail'),
						'phone' => $this->input->post('ophone'),
						'address' => $this->input->post('oaddress'),
						'industry' => $this->input->post('industry'),
						'status' => 1,
						'datetime' => @time()
					);
					
					if ($_FILES['logo']['name']){
						
						$imagename = $orgnumber; $checkerror = ""; $fileext1 = @end(@explode('/', $_FILES['logo']['type'])); 
						$_FILES['logo']['name'] = $imagename.'.'.$fileext1; $datainsert['logo'] = 'uploads/organization/'.$imagename.'.'.$fileext1;
								
						$config['upload_path'] = './uploads/organization/';
						$config['allowed_types'] = 'gif|jpg|jpeg|png';
						$config['max_size'] = 1024;
						$config['overwrite'] = TRUE;
						
						$this->load->library('upload', $config);
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('logo')){ $data['error'] = 4; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
			
						if (!$checkerror){
							$last_id = $this->organization_model->insert_record($datainsert);
							redirect('control/organization/edit_view/'.$last_id.'/new');
						}
					}
					
					
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "organization"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
		
	}
	
	/* add new end */
	
	/* edit start */
	public function edit_view(){
		$data = array();
		$orgID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("organization", array("id" => $orgID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'sb_new'){ $data['errorS'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'reset'){ $data['error'] = 9; }else{ $data['error'] = 0; }
		$data['page'] = "organization"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $orgID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('oname', 'oname', 'required');
		$this->form_validation->set_rules('oemail', 'oemail', 'required');
		$this->form_validation->set_rules('ophone', 'ophone', 'required');
		$this->form_validation->set_rules('oaddress', 'oaddress', 'required');
		$this->form_validation->set_rules('industry', 'industry', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 5; }
		else{
			$query = $this->db->get_where('organization', array('id!=' => $orgID, 'name' =>  $this->input->post('oname'), 'email' =>  $this->input->post('oemail'), 'phone' =>  $this->input->post('ophone'), 'industry' =>  $this->input->post('industry'))); 
			$result['organization'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 6; }
			else{
				$datainsert = array(
					'name' => $this->input->post('oname'),
					'email' => $this->input->post('oemail'),
					'phone' => $this->input->post('ophone'),
					'address' => $this->input->post('oaddress'),
					'industry' => $this->input->post('industry')
				);
				
				$checkerror = "";
				if ($_FILES['logo']['name']){
						
					$imagename = $this->input->post('onumber');  $fileext1 = @end(@explode('/', $_FILES['logo']['type'])); 
					$_FILES['logo']['name'] = $imagename.'.'.$fileext1; $datainsert['logo'] = 'uploads/organization/'.$imagename.'.'.$fileext1;
								
					$config['upload_path'] = './uploads/organization/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png';
					$config['max_size'] = 1024;
					$config['overwrite'] = TRUE;
						
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('logo')){ $data['error'] = 7; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
				}
				if (!$checkerror){
					$this->organization_model->update_record($orgID, $datainsert);
					$data['error'] = 8;
				}
			}
		}
		
		$query = $this->db->get_where("organization", array("id" => $orgID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "organization"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function resetpasscode(){
		$data = array(); $orgID = $this->uri->segment('4');
		$this->organization_model->update_record($orgID, array('passcode' => encrypt_decrypt('encrypt', generate_password())));
		redirect('control/organization/edit_view/'.$orgID.'/reset');
	}
	
	/* edit new end */
	
	/* subcat addsubscription */
	public function addsubscription(){
		$data = array(); $orgID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('amount', 'amount', 'required');
		$this->form_validation->set_rules('sdate', 'sdate', 'required');
		$this->form_validation->set_rules('duration', 'duration', 'required');
		$this->form_validation->set_rules('enddate', 'enddate', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['errorS'] = 1; }
		else{
			$sdate = @strtotime($this->input->post('sdate')); $enddate = @strtotime($this->input->post('enddate'));
			$query = $this->db->get_where('subscription', array('organization' => $orgID, 'starttime' => $sdate, 'endtime' => $enddate, 'duration' =>  $this->input->post('duration'))); 
			//$result['subscription'] = $query->result();
			if ($query->num_rows() > 0){ $data['errorS'] = 2; }
			else{
				$randnumber = 211321; $orgnumber = "";
				$query = $this->db->query("select * from subscription order by id DESC LIMIT 1");
				if ($query->num_rows() > 0){ $result['subscription'] = $query->result(); $orgnumber = "$orgID".($result['subscription'][0]->id+$randnumber); }
				else{ $orgnumber = "$orgID".$randnumber; }
				
				$mystatus = 1; if ($enddate < @time()){ $mystatus = 0; }
					
				$datainsert = array(
					'transno' => $orgnumber,
					'organization' => $orgID,
					'amount' => $this->input->post('amount'),
					'duration' => $this->input->post('duration'),
					'starttime' => $sdate,
					'endtime' => $enddate,
					'status' => $mystatus,
					'datetime' => @time()
				);
				$this->db->insert('subscription', $datainsert);
				
				if ($mystatus == 1){
					//send email
					$query = $this->db->get_where('organization', array('id' =>  $orgID)); $result['organization'] = $query->result();
					$myemail = $result['organization'][0]->email; $myname = $result['organization'][0]->name;
					
					$query = $this->db->get('settings'); $result['settings2'] = $query->result(); 
					$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
					
					$subject = "New Subscription Added - ".$result['settings2'][0]->appowner; 
					
					$emaildata['message'] = "New subscription was just added to your account find details below: <br><br>".
					"Transaction Number: <b>$orgnumber</b> <br>Amount: <b>&#x20A6; ".@number_format($this->input->post('amount'))."</b>".
					"<br>Start date: <b>".@date('M d, Y', $sdate)."</b> <br>End Date: <b>".@date('M d, Y', $enddate)."</b>";
					
					$emaildata['first_name'] = $myname; //$emaildata['link'] = site_url('index.php/control/index'); $emaildata['link_name'] = "ADMIN LOGIN PAGE"; 
					$emaildata['settings'] = $this->settings_model->getSettings();
					$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
										
					send_email_phpmailer($appemail, $appname, $appemail, $appname, $myemail, $subject, $message);
					//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				}
				
				redirect('control/organization/edit_view/'.$orgID.'/sb_new');
				//$data['errorS'] = 8;
				
			}
		}
		
		$query = $this->db->get_where("organization", array("id" => $orgID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "organization"; $data['whattodo'] = "edit"; $data['error'] = 0;
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* subcat addsubscription */
	
	public function disable_process(){
		$data = array(); $orgID = $this->uri->segment('4');
		
		$this->organization_model->update_record($orgID, array('status' => '0')); $data['ADerror'] = 1;
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "organization"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array(); $orgID = $this->uri->segment('4');
		
		$this->organization_model->update_record($orgID, array('status' => '1')); $data['ADerror'] = 2;
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "organization"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/organization', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

        $total_record = $this->organization_model->total_record();
		$categories = $this->organization_model->get_record($length, $start);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$query = $this->db->order_by("endtime", "desc")->get_where('subscription', array('organization' =>  $r->id, 'status' =>  1, 'endtime>=' =>  @time()));
			if ($query->num_rows()>0){
				$result['subscription'] = $query->result();
				if ($result['subscription'][0]->endtime < (@time() + (60 * 60 * 24 * 30))){ $statusS = "<span class='label label-warning'>about to expire</span>"; }
				else{ $statusS = "<span class='label label-primary'>have subscription</span>"; }
			}else{ $statusS = "<span class='label label-danger'>no subscription</span>"; }
			
			$query = $this->db->get_where('industry', array('id' =>  $r->industry)); $result['industry'] = $query->result();
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/organization/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
			if ($r->status==1) $links .= "<a href='".site_url('index.php/control/organization/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->name?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('index.php/control/organization/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->name?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "<a href='index.php/control/osession/index/".$r->id."' target='_blank' data-toggle='tooltip' title='account' class='btn btn-xs btn-primary'><i class='fa fa-tachometer'></i> account</a></div></td>";
			
			$data[] = array(
				"$status | $statusS<br><img src='".$r->logo."' width='100'>",
				"<font size=4><b>".$r->name."</b></font><br>".$r->email." | ".$r->phone."",
				"".$r->address."",
				"".$result['industry'][0]->industry."",
				$links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
