<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class receipt extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('products_model');
		$this->load->model('location_model');
		$this->load->model('order_model');
		$this->load->model('cart_model');
		$this->load->model('clients_model');
		$this->load->model('admin_model');
		$this->load->model('stock_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "receipt"; $data['whattodo'] = "add";
		
		//$this->load->view('control/p_header', $data);
		$this->load->view('control/receipt', $data);
		//$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	
	
	
	
}
