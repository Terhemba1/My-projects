<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array(); $slideupload = $this->uri->segment('4'); 
		
		if (isset($slideupload)){ 
			if (strpos($slideupload, 'slide') !== false){ $data['slide'] = $slideupload; $data['error'] = 2; }else{ $data['error'] = 0; } 
		}else{ $data['error'] = 0; }
		$data['page'] = "settings";
		$data['settings'] = $this->settings_model->getSettings();
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/settings', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function upload(){
		$data = array(); $settingID = 1; 
		
		if (isset($_FILES['slide_image']['name'])){
			if ($_FILES['slide_image']['name']){
				$getfname1 = strlen(@end(@explode('.', $this->input->post('large_image_old')))) + 1; 
					$getfname1x = $this->input->post('slide'); $oldslide = $this->input->post('slide_old');
					
					$fileext2 = @end(@explode('/', $_FILES['slide_image']['type']));
					$datainsert['slide_image'] = "uploads/settings/".$getfname1x.'.'.$fileext2;
					
					$_FILES['slide_image']['name'] = $getfname1x.'.'.$fileext2;
					
					$config['upload_path'] = './uploads/settings/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png';
					$config['max_size'] = 2048;
					$config['overwrite'] = TRUE;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('slide_image')){ 
						$data['slide'] = $this->input->post('slide'); $data['error'] = 1; $data['error_msg'] = $this->upload->display_errors(); 
					}else{ redirect('control/settings/index/'.$this->input->post('slide')); }
			}
		}
				
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "settings";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/settings', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function update_settings(){
		$data = array(); $settingID = 1; 
		$this->form_validation->set_rules('wname', 'Website name', 'required');
		//$this->form_validation->set_rules('wdesc', 'description', 'required');
		//$this->form_validation->set_rules('email', 'sender email', 'required|valid_email');
		//$this->form_validation->set_rules('epass', 'sender password', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 3; }
		else{
			$datainsert = array(
				'appowner' => $this->input->post('wname'), 
				'description' => '', 
				'email_sender' => '',
				'sender_password' => ''
			);
			
			$checkerror = "";
			if ($_FILES['llogo']['name']){
					$getfname1x = "logo_large";
					
					$fileext1 = @end(@explode('/', $_FILES['llogo']['type']));
					$datainsert['logo_large'] = "uploads/settings/".$getfname1x.'.'.$fileext1;
					
					$_FILES['llogo']['name'] = $getfname1x.'.'.$fileext1;
					
					$config['upload_path'] = './uploads/settings/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png';
					$config['max_size'] = 400;
					$config['overwrite'] = TRUE;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('llogo')){ $data['error'] = 5; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
			}
			
			if (!$checkerror){
				$checkerror = "";
				if ($_FILES['logo']['name']){
					$getfname1x = "logo";
					
					$fileext1 = @end(@explode('/', $_FILES['logo']['type']));
					$datainsert['logo'] = "uploads/settings/".$getfname1x.'.'.$fileext1;
					
					$_FILES['logo']['name'] = $getfname1x.'.'.$fileext1;
					
					$config['upload_path'] = './uploads/settings/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png';
					$config['max_size'] = 200;
					$config['overwrite'] = TRUE;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('logo')){ $data['error'] = 6; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
				}	
				
				if (!$checkerror){
					$checkerror = "";
					if ($_FILES['icon']['name']){
						$getfname1x = "icon";
						
						$fileext1 = @end(@explode('/', $_FILES['icon']['type']));
						$datainsert['icon'] = "uploads/settings/".$getfname1x.'.'.$fileext1;
						
						$_FILES['icon']['name'] = $getfname1x.'.'.$fileext1;
						
						$config['upload_path'] = './uploads/settings/';
						$config['allowed_types'] = 'gif|jpg|jpeg|png';
						$config['max_size'] = 100;
						$config['overwrite'] = TRUE;
						
						$this->load->library('upload', $config);
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('icon')){ $data['error'] = 7; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
					}
					
					/*if (!$checkerror){
						$checkerror = "";
						if ($_FILES['aimage']['name']){
							$getfname1x = "aimage";
							
							$fileext1 = @end(@explode('/', $_FILES['aimage']['type']));
							$datainsert['aimage'] = "uploads/settings/".$getfname1x.'.'.$fileext1;
							
							$_FILES['aimage']['name'] = $getfname1x.'.'.$fileext1;
							
							$config['upload_path'] = './uploads/settings/';
							$config['allowed_types'] = 'gif|jpg|jpeg|png';
							$config['max_size'] = 500;
							$config['overwrite'] = TRUE;
							
							$this->load->library('upload', $config);
							$this->upload->initialize($config);
							if (!$this->upload->do_upload('aimage')){ $data['error'] = 8; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
						}*/
						
						if (!$checkerror){
							$this->settings_model->updateSettings($settingID, $datainsert);
							$data['error'] = 4;
						}
					//}
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "settings";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/settings', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function about(){
		$data = array(); $slideupload = $this->uri->segment('4');
		$data['error'] = 0; $data['page'] = "about";
		$data['settings'] = $this->settings_model->getSettings();
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/about', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function update_about(){
		$data = array(); $settingID = 1; 
		$this->form_validation->set_rules('about', 'About', 'required');
		$this->form_validation->set_rules('description', 'description', 'required');
		$this->form_validation->set_rules('keyword', 'keyword', 'required');
		$this->form_validation->set_rules('terms', 'Terms', 'required');
		$this->form_validation->set_rules('faq', 'FAQ', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$datainsert = array(
				'about_l' => $this->input->post('about'), 
				'about' => $this->input->post('description'), 
				'keyword' => $this->input->post('keyword'),
				'terms' => $this->input->post('terms'),
				'loyalty' => $this->input->post('loyalty'),
				'faq' => $this->input->post('faq')
			);
			
			$this->settings_model->updateSettings($settingID, $datainsert);
			$data['error'] = 2;
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "about";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/about', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function contact(){
		$data = array(); $data['error'] = 0; $data['page'] = "contact";
		$data['settings'] = $this->settings_model->getSettings();
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/contact', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function contact_update(){
		$data = array(); $settingID = 1; 
		$this->form_validation->set_rules('email1', 'email address 1', 'required|valid_email');
		//$this->form_validation->set_rules('email2', 'email address 2', 'required|valid_email');
		$this->form_validation->set_rules('phone1', 'phone number 1', 'required');
		//$this->form_validation->set_rules('phone2', 'phone number 2', 'required');
		$this->form_validation->set_rules('address', 'address', 'required');
		//$this->form_validation->set_rules('address_g', 'address map', 'required');
		//$this->form_validation->set_rules('facebook', 'facebook', 'required');
		//$this->form_validation->set_rules('twitter', 'twitter', 'required');
		//$this->form_validation->set_rules('intagram', 'intagram', 'required');
		//$this->form_validation->set_rules('linkedin', 'Linkedin', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$datainsert = array(
				'email' => $this->input->post('email1'), 
				'email1' => $this->input->post('email2'),
				'phone' => $this->input->post('phone1'),
				'phone1' => $this->input->post('phone2'),				
				'address' => $this->input->post('address'),
				'address_g' => $this->input->post('address_g'), 
				'facebook' => $this->input->post('facebook'),
				'twitter' => $this->input->post('twitter'),
				'intagram' => $this->input->post('intagram'), 
				'linkedin' => $this->input->post('linkedin')
			);
			
			$this->settings_model->updateSettings($settingID, $datainsert);
			$data['error'] = 2;
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "contact";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/contact', $data);
		$this->load->view('control/p_footer', $data);
	}
	
}
