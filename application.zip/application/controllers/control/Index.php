<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->model('admin_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('email');
		$this->load->library('email');
		$this->load->helper('all_functions');
		
		$sessprefix = $this->config->item('sess_prefix');
		$this->session->unset_userdata(array($sessprefix.'lock_admin_user_id', $sessprefix.'lock_admin_user_email', $sessprefix.'lock_admin_user_fname', $sessprefix.'lock_admin_user_password', $sessprefix.'lock_admin_user_clearance', $sessprefix.'lock_referrer'));
    }
	  
	public function index(){
		$data = array(); $sessprefix = $this->config->item('sess_prefix');
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0;
		if (!$this->session->userdata($sessprefix.'admin_user_id')){
			$this->load->view('control/index', $data);
		}else{
			redirect('control/dashboard');
		}
	}
	
	/* dashboard permission control start */
	public function login(){
		$this->form_validation->set_rules('login_email', 'Email Address', 'required');
		$this->form_validation->set_rules('login_password', 'Password', 'required');
		$sessprefix = $this->config->item('sess_prefix');
		
		if ($this->form_validation->run() == FALSE) {
			$data = array();
			$data['settings'] = $this->settings_model->getSettings();
			$data['error'] = "1";
			
			$this->load->view('control/index', $data);
		}else{
			$data = array(
				'email' => $this->input->post('login_email'), 
				'password' => md5($this->input->post('login_password')),
			);
			//$this->db->select('title, content, date'); 
			$query = $this->db->get_where('users', $data, 1);
			$result['users'] = $query->result();
			if ($query->num_rows() == 0) {
				$data = array();
				$data['settings'] = $this->settings_model->getSettings();
				$data['error'] = "2";
				
				$this->load->view('control/index', $data);
			}else{
				if ($result['users'][0]->status == 0){
					$data = array();
					$data['settings'] = $this->settings_model->getSettings();
					$data['error'] = "3";
					
					$this->load->view('control/index', $data);
				}else{
					 $this->session->set_userdata('status', $result['users'][0]->status);
					  $this->session->set_userdata('distributor', $result['users'][0]->distributorid);
					$sessiondata = array(
						$sessprefix.'admin_user_id' => $result['users'][0]->id, 
						$sessprefix.'admin_user_email' => $result['users'][0]->email,
						$sessprefix.'admin_user_fname' => $result['users'][0]->first_name,
						$sessprefix.'admin_user_password' => $result['users'][0]->password,
						$sessprefix.'admin_user_clearance' => $result['users'][0]->clearance,
						$sessprefix.'admin_user_llogin' => $result['users'][0]->last_login,
						$sessprefix.'admin_user_status' => $result['users'][0]->status
					);
					$this->session->set_userdata($sessiondata);
					
					$this->admin_model->update_record($result['users'][0]->id, array('last_login' => @time()));
					redirect('control/dashboard');
				}
			}
		}
	}
	public function logout(){
		$sessprefix = $this->config->item('sess_prefix');
		$this->session->unset_userdata(array($sessprefix.'admin_user_id', $sessprefix.'admin_user_email', $sessprefix.'admin_user_fname', $sessprefix.'admin_user_password', $sessprefix.'admin_user_clearance'));
		$this->session->unset_userdata(array($sessprefix.'lock_admin_user_id', $sessprefix.'lock_admin_user_email', $sessprefix.'lock_admin_user_fname', $sessprefix.'lock_admin_user_password', $sessprefix.'lock_admin_user_clearance', $sessprefix.'lock_referrer'));
		
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 4;
		$this->load->view('control/index', $data);
	}
	public function no_permission(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 5;
		$this->load->view('control/index', $data);
	}
	/* dashboard permission control end */
	
	/* reset password start */
	public function reset_password(){
		$data = array();
		$passres = $this->uri->segment('4');
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "email";
		if (isset($passres)){ if ($passres=='done'){ $data['error'] = 9; }else{ $data['error'] = 0; } }
		
		$this->load->view('control/reset_password', $data);
	}
	public function reset_password_email(){
		$this->form_validation->set_rules('login_email', 'Email Address', 'required');
		
		$data = array(); $sessprefix = $this->config->item('sess_prefix');
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('users', array('email' => $this->input->post('login_email')), 1);
			if ($query->num_rows() == 0) { $data['error'] = 2; }
			else{
				$result['users'] = $query->result(); $adminid = $result['users'][0]->id; $adminname = $result['users'][0]->first_name;
				$frgpasscode = encrypt_decrypt('encrypt', $adminid.'-'.(@time() + (24*60*60)));
				$this->admin_model->update_record($adminid, array('frgpasswordcode' => $frgpasscode));
				
				$query = $this->db->get('settings');
				$result['settings2'] = $query->result();
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
				
				$to_email = $this->input->post('login_email');
				$subject = $result['settings2'][0]->appowner." - Password Reset Link"; 
										
				$emaildata['message'] = "Please click the below button to you reset your password".
				"<br>{note this link expires in 24 hours}";
				$emaildata['link'] = site_url('index.php/control/index/reset_my_password/'.$frgpasscode); $emaildata['link_name'] = "RESET MY PASSWORD";
				$emaildata['settings'] = $this->settings_model->getSettings();
				$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
										
				$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
										
				send_email_phpmailer($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				
				$data['error'] = 3;
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "email";
		
		$this->load->view('control/reset_password', $data);
	}
	public function reset_my_password(){
		$data = array();
		$resetcode = encrypt_decrypt('decrypt', $this->uri->segment('4'));
		if (!isset($resetcode)){ $data['page'] = "email"; }
		else{
			$resetcodebrk = @explode('-', $resetcode);
			$query = $this->db->get_where('users', array('id' => $resetcodebrk[0]), 1);
			if ($query->num_rows() == 0) { $data['error'] = 4; $data['page'] = "email"; }
			else{
				if (@time() > $resetcodebrk[1]){ $data['error'] = 5; $data['page'] = "email"; }
				else{
					$data['error'] = 0; $data['page'] = "new"; $data['link'] = $this->uri->segment('4');
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		
		$this->load->view('control/reset_password', $data);
	}
	public function reset_password_new(){
		$this->form_validation->set_rules('new_password', 'new password', 'required');
		$this->form_validation->set_rules('password_meterV', 'password meter', 'required');
		$this->form_validation->set_rules('confrim_password', 'confirm password', 'required');
		$this->form_validation->set_rules('conf_meterV', 'confirm meter', 'required');
		$resetcode = encrypt_decrypt('decrypt', $this->uri->segment('4')); 
		
		$data = array(); $data['link'] = $this->uri->segment('4');
		if (!isset($resetcode)){ $data['page'] = "email"; }
		else{
			$resetcodebrk = @explode('-', $resetcode);
			$query = $this->db->get_where('users', array('id' => $resetcodebrk[0]), 1);
			if ($query->num_rows() == 0) { $data['error'] = 4; $data['page'] = "email"; }
			else{
				$result['users'] = $query->result(); $adminid = $result['users'][0]->id; $adminemail = $result['users'][0]->email;
				if (@time() > $resetcodebrk[1]){ $data['error'] = 5; $data['page'] = "email"; }
				else{
					//$data['error'] = 0; $data['page'] = "new"; $data['link'] = $this->uri->segment('4');
					
					if ($this->form_validation->run() == FALSE) { $data['error'] = 6; $data['page'] = "new"; }
					else{
						if ($this->input->post('password_meterV') < 50) { $data['error'] = 7; $data['page'] = "new"; }
						else{
							if ($this->input->post('conf_meterV') == 0) { $data['error'] = 8; $data['page'] = "new"; }
							else{
								$newpass = md5($this->input->post('new_password'));
								$this->admin_model->update_record($adminid, array('frgpasswordcode' => '', 'password' => $newpass));
								
								$query = $this->db->get('settings');
								$result['settings2'] = $query->result();
								$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
								
								$to_email = $adminemail;
								$subject = $result['settings2'][0]->appowner." - Your Password Reset Successfully"; 
														
								$emaildata['message'] = "Your password was reset successfully";
								$emaildata['settings'] = $this->settings_model->getSettings();
								$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
														
								$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
														
								send_email_phpmailer($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
								//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				
								redirect('control/index/reset_password/done');
							}
						}
					}
				}
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$this->load->view('control/reset_password', $data);
	}
	/* reset password end */
	
}
