<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ostaff extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('state_model');
		$this->load->model('ostaff_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "ostaff"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "ostaff"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function load_role(){
		$dept = $this->uri->segment('4');
		$query = $this->db->query("select * from role where dept='".$dept."' and status='1'");
		if ($query->num_rows() > 0){
			echo "<option value=''>--Select Role--</option>";
			foreach ($query->result_array() as $row){ echo "<option value='".$row['id']."'>".$row['role']."</option>"; }
		}
		
	}
	
	public function add_process(){
		$organizationID = $this->uri->segment('4');
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('grade', 'grade', 'required');
		$this->form_validation->set_rules('dept', 'dept', 'required');
		$this->form_validation->set_rules('role', 'role', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE){ $data['error'] = 1; }
		else{
			
				$query = $this->db->get_where('staff', array('email' =>  $this->input->post('email'), 'organization' => $organizationID)); 
				$result['staff'] = $query->result();
				if ($query->num_rows() > 0){ $data['error'] = 2; }
				else{
					$datainsert = array(
						'organization' => $organizationID,
						'email' => $this->input->post('email'),
						'name' => $this->input->post('name'),
						'grade' => $this->input->post('grade'),
						'dept' => $this->input->post('dept'),
						'role' => $this->input->post('role'),
						'datetime' => @time(),
						'status' => 1
					);
					
					$last_id = $this->ostaff_model->insert_record($datainsert);
					redirect('control/ostaff/edit_view/'.$organizationID.'/'.$last_id.'/new');
						
				}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "ostaff"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
		
	}
	
	/* add new end */
	
	/* edit start */
	public function edit_view(){
		$data = array(); $organizationID = $this->uri->segment('4'); $staffID = $this->uri->segment('5'); $newstatus = $this->uri->segment('6');
		$query = $this->db->get_where("staff", array("id" => $staffID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'ueval'){ $data['errorS'] = 1; $data['error'] = 0; }
		elseif ($newstatus == 'reset'){ $data['error'] = 9; }else{ $data['error'] = 0; }
		$data['page'] = "ostaff"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $organizationID = $this->uri->segment('4'); $staffID = $this->uri->segment('5'); 
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('grade', 'grade', 'required');
		$this->form_validation->set_rules('dept', 'dept', 'required');
		$this->form_validation->set_rules('role', 'role', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['error'] = 5; }
		else{
			$query = $this->db->get_where('staff', array('id!=' => $staffID, 'email' =>  $this->input->post('email'), 'organization' => $organizationID));
			$result['staff'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 6; }
			else{
				$datainsert = array(
					'email' => $this->input->post('email'),
					'name' => $this->input->post('name'),
					'grade' => $this->input->post('grade'),
					'dept' => $this->input->post('dept'),
					'role' => $this->input->post('role')
				);
				
				$this->ostaff_model->update_record($staffID, $datainsert);
				$data['error'] = 7;
			}
		}
		
		$query = $this->db->get_where("staff", array("id" => $staffID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "ostaff"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function evaluator(){
		$data = array(); $organizationID = $this->uri->segment('4'); $staffID = $this->uri->segment('5');
		$coll = "";
		if ($this->input->post('tnumstaff') > 0){
			$this->db->delete('evaluator', array('evaluatee' => $staffID, 'type' => $this->input->get('manage'), 'organization' => $organizationID)); 
			for ($i=0; $i<$this->input->post('tnumstaff'); $i++){
				if ($this->input->post('estaff'.$i)){
					//$coll .= ", ".$this->input->post('estaff'.$i);
					$evid = "EV".$organizationID.$staffID.$this->input->post('estaff'.$i);
					$datainsert = array( 
						'id' => $evid, 
						'organization' => $organizationID, 
						'type' => $this->input->get('manage'), 
						'evaluatee' => $staffID, 
						'evaluator' => $this->input->post('estaff'.$i), 
						'datetime' => @time()
					);
					$this->db->insert('evaluator', $datainsert);
				}
			}
			//$data['errorMSG'] = $coll;
			redirect('control/ostaff/edit_view/'.$organizationID.'/'.$staffID.'/ueval?manage='.$this->input->get('manage').'#manage');
		}
		
		$query = $this->db->get_where("staff", array("id" => $staffID)); $data['records'] = $query->row();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "ostaff"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new end */
	
	/* subcat addsubscription */
	public function addsubscription(){
		$data = array(); $staffID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('amount', 'amount', 'required');
		$this->form_validation->set_rules('sdate', 'sdate', 'required');
		$this->form_validation->set_rules('duration', 'duration', 'required');
		$this->form_validation->set_rules('enddate', 'enddate', 'required');
		
		if ($this->form_validation->run() == FALSE) { $data['errorS'] = 1; }
		else{
			$sdate = @strtotime($this->input->post('sdate')); $enddate = @strtotime($this->input->post('enddate'));
			$query = $this->db->get_where('subscription', array('staff' => $staffID, 'starttime' => $sdate, 'endtime' => $enddate, 'duration' =>  $this->input->post('duration'))); 
			//$result['subscription'] = $query->result();
			if ($query->num_rows() > 0){ $data['errorS'] = 2; }
			else{
				$randnumber = 211321; $orgnumber = "";
				$query = $this->db->query("select * from subscription order by id DESC LIMIT 1");
				if ($query->num_rows() > 0){ $result['subscription'] = $query->result(); $orgnumber = "$staffID".($result['subscription'][0]->id+$randnumber); }
				else{ $orgnumber = "$staffID".$randnumber; }
				
				$mystatus = 1; if ($enddate < @time()){ $mystatus = 0; }
					
				$datainsert = array(
					'transno' => $orgnumber,
					'staff' => $staffID,
					'amount' => $this->input->post('amount'),
					'duration' => $this->input->post('duration'),
					'starttime' => $sdate,
					'endtime' => $enddate,
					'status' => $mystatus,
					'datetime' => @time()
				);
				$this->db->insert('subscription', $datainsert);
				
				if ($mystatus == 1){
					//send email
					$query = $this->db->get_where('staff', array('id' =>  $staffID)); $result['staff'] = $query->result();
					$myemail = $result['staff'][0]->email; $myname = $result['staff'][0]->name;
					
					$query = $this->db->get('settings'); $result['settings2'] = $query->result(); 
					$appemail = $result['settings2'][0]->email; $appname = $result['settings2'][0]->appowner;
					
					$subject = "New Subscription Added - ".$result['settings2'][0]->appowner; 
					
					$emaildata['message'] = "New subscription was just added to your account find details below: <br><br>".
					"Transaction Number: <b>$orgnumber</b> <br>Amount: <b>₦ ".@number_format($this->input->post('amount'))."</b>".
					"<br>Start date: <b>".@date('M d, Y', $sdate)."</b> <br>End Date: <b>".@date('M d, Y', $enddate)."</b>";
					
					$emaildata['first_name'] = $myname; //$emaildata['link'] = site_url('index.php/control/index'); $emaildata['link_name'] = "ADMIN LOGIN PAGE"; 
					$emaildata['settings'] = $this->settings_model->getSettings();
					$message = $this->load->view('email_template/email_contact.php', $emaildata, TRUE);;
										
					send_email_phpmailer($appemail, $appname, $appemail, $appname, $myemail, $subject, $message);
					//send_email_codeigniter($appemail, $appname, $appemail, $appname, $to_email, $subject, $message);
				}
				
				redirect('control/ostaff/edit_view/'.$staffID.'/sb_new');
				//$data['errorS'] = 8;
				
			}
		}
		
		$query = $this->db->get_where("staff", array("id" => $staffID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "ostaff"; $data['whattodo'] = "edit"; $data['error'] = 0;
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* subcat addsubscription */
	
	public function disable_process(){
		$data = array(); $organizationID = $this->uri->segment('4'); $staffID = $this->uri->segment('5');
		
		$this->ostaff_model->update_record($staffID, array('status' => '0')); $data['ADerror'] = 1;
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "ostaff"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array(); $organizationID = $this->uri->segment('4'); $staffID = $this->uri->segment('5');
		
		$this->ostaff_model->update_record($staffID, array('status' => '1')); $data['ADerror'] = 2;
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "ostaff"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/ostaff', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

		$organizationID = $this->uri->segment('4');
        $total_record = $this->ostaff_model->total_record($organizationID);
		$categories = $this->ostaff_model->get_record($length, $start, $organizationID);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$query = $this->db->get_where('dept', array('id' =>  $r->dept)); $result['dept'] = $query->result();
			$query = $this->db->get_where('role', array('id' =>  $r->role)); $result['role'] = $query->result();
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/ostaff/edit_view/".$organizationID."/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
			if ($r->status==1) $links .= "<a href='".site_url('index.php/control/ostaff/disable_process/'.$organizationID.'/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->email [$r->name]?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('index.php/control/ostaff/enable_process/'.$organizationID.'/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->email [$r->name]?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div></td>";
			
			$data[] = array(
				"$status <br> <b>".$r->email."</b>",
				"<b>".$r->name."</b>",
				"".$r->grade."",
				"".$result['dept'][0]->dept."",
				"".$result['role'][0]->role."",
				$links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
