<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Oreport extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('state_model');
		$this->load->model('oreport_model');
		$this->load->helper("all_functions");
		
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "oreport"; $data['whattodo'] = "";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/oreport', $data);
		//$this->load->view('control/p_footer', $data);
	}
	
	public function reportstaff(){
		$data = array(); $organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
		
		$staffID = $this->input->get('who');
		$query = $this->db->get_where("staff", array("id" => $staffID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "oreport"; $data['whattodo'] = "edit"; $data['error'] = 0;
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/oreport', $data);
		//$this->load->view('control/p_footer', $data);
	}
	
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

		$organizationID = $this->uri->segment('4'); $sessionID = $this->uri->segment('5');
        $total_record = $this->oreport_model->total_record($organizationID);
		$categories = $this->oreport_model->get_record($length, $start, $organizationID);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$query = $this->db->get_where('dept', array('id' =>  $r->dept)); $result['dept'] = $query->result();
			$query = $this->db->get_where('role', array('id' =>  $r->role)); $result['role'] = $query->result();
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/oreport/reportstaff/".$organizationID."/".$sessionID."?how=staff&who=".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-eye'></i> view report</a>";
			//if ($r->status==1) $links .= "<a href='".site_url('index.php/control/oreport/disable_process/'.$organizationID.'/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->email [$r->name]?\")'><i class='fa fa-times'></i> deactivate</a>";
			//else $links .= "<a href='".site_url('index.php/control/oreport/enable_process/'.$organizationID.'/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->email [$r->name]?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div></td>";
			
			$data[] = array(
				"$status <br> <b>".$r->email."</b>",
				"<b>".$r->name."</b>",
				"".$r->grade."",
				"".$result['dept'][0]->dept."",
				"".$result['role'][0]->role."",
				$links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
