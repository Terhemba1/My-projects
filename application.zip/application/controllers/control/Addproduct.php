<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addproduct extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('location_model');
		$this->load->model('agents_model');
		$this->load->model('addproduct_model');
		$this->load->model('admin_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "addproduct"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "addproduct"; $data['whattodo'] = "add";
		$data['location'] = $this->location_model->get_all_record();
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('pname', 'pname', 'required');
		$this->form_validation->set_rules('amount', 'amount', 'required');
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('product', array('pname' => $this->input->post('pname'), 'status' => '1'));
			$result['category'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 2; }
			else{
		
				
			if ($_FILES['picture']['name']){
					$getfname1x = "products";
					$ran = rand(1000,3000);
					$a= $getfname1x.$ran;
					$fileext1 = @end(@explode('/', $_FILES['picture']['type']));
					$datainsert['picture'] = "files/products/".$a.'.'.$fileext1;
					$imgname =  "files/products/".$a.'.'.$fileext1;
					$_FILES['picture']['name'] = $a.'.'.$fileext1;
					
					$config['upload_path'] = './files/products/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png';
					$config['max_size'] = 4000;
					$config['overwrite'] = TRUE;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('picture')){ $data['error'] = 5; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
			}
				
				$datainserts = array(
					'pname' => $this->input->post('pname'),
					'amount' =>  $this->input->post('amount'),
					'amount2' =>  $this->input->post('amount2'),
					'quantity' =>  $this->input->post('quantity'),
					'quantity2' =>  $this->input->post('quantity2'),
					'procat' =>  $this->input->post('procat'),
					'added_date' => @time(),
					'total' => $this->input->post('quantity'),
					'total2' => $this->input->post('quantity2'),
					'imglink' => $imgname,
					'status' => 1
				);
			if	($this->addproduct_model->insert_record($datainserts)){$data['error'] = 10;}
				
				
				
				 //$data['error'] = 10;
				
				redirect('control/addproduct/add_view');
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "addproduct"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	

	public function wrong_entry_view(){
		$data = array();
		$valueID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("product", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'qnew'){ $data['errorT'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'removed'){ $data['errorT'] = 4; $data['error'] = 0; }else{ $data['error'] = 0; }
		$data['page'] = "addproduct"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}

	public function edit_wrong(){
		$this->uri->segment('4');
		$data = array(); $data = array(); $valueID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('pname', 'pname', 'required');
			if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			
				$total = (int)($this->input->post('total'))+0;
				$total2 = (int)($this->input->post('total2'))+0;
				$amount = $this->input->post('amount');
				$amount2 = $this->input->post('amount2');
				$pname = $this->input->post('pname');
				 $query = $this->db->query("update product set pname = '$pname', total = '$total', total2 = '$total2', amount = '$amount' , amount2 = '$amount2' where id='$valueID'");
					
				
				redirect('control/addproduct/index?d=done');
			}


}

	
	/* add new category end */
	
	/* edit new category start */
	public function edit_view(){
		$data = array();
		$valueID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("product", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'qnew'){ $data['errorT'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'removed'){ $data['errorT'] = 4; $data['error'] = 0; }else{ $data['error'] = 0; }
		$data['page'] = "addproduct"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$this->uri->segment('4');
		$data = array(); $data = array(); $valueID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('pname', 'pname', 'required');
			if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			

				if ($_FILES['picture']['name']){
					$getfname1x = "products";
					$ran = rand(1000,3000);
					$a= $getfname1x.$ran;
					$fileext1 = @end(@explode('/', $_FILES['picture']['type']));
					$datainsert['picture'] = "files/products/".$a.'.'.$fileext1;
					$imgname =  "files/products/".$a.'.'.$fileext1;
					$_FILES['picture']['name'] = $a.'.'.$fileext1;
					
					$config['upload_path'] = './files/products/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png';
					$config['max_size'] = 4000;
					$config['overwrite'] = TRUE;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('picture')){ $data['error'] = 5; $data['error_msg'] = $this->upload->display_errors(); $checkerror = "yes"; }
			}else{$imgname = "";}
				$howmany = $this->input->post('howmany');
				$imglink = $imgname;
				$quantity = (int)($this->input->post('quantity'))+0;
				$quantity2 = (int)($this->input->post('quantity2'))+0;
				$amount = $this->input->post('amount');
				$amount2 = $this->input->post('amount2');
				$pname = $this->input->post('pname');
				 $query = $this->db->query("update product set pname = '$pname', total = total+$quantity, total2 = total2+$quantity2, amount = '$amount', amount2 = '$amount2', imglink = '$imglink', howmany = '$howmany' where id='$valueID'");
					
				
				redirect('control/addproduct/index/done');
			}
		
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "addproduct"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function arrange(){
		$data = array(); $valueID = $this->uri->segment('4'); 
		if ($this->input->get('q')){
			if ($this->input->get('up')){
				$query = $this->db->order_by('arrange', 'desc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange<' => $this->input->get('up'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('up')));
			
			}elseif($this->input->get('down')){
				$query = $this->db->order_by('arrange', 'asc')->get_where('lquestion', array('status' => 1, 'lca' => $valueID, 'arrange>' => $this->input->get('down'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('lquestion', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('lquestion', array('arrange' => $this->input->get('down')));
				
			}
			redirect('control/addproduct/edit_view/'.$valueID.'#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "addproduct"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new category end */
	
	/* change enable and disable status start */
	
	public function remove(){
		$data = array(); $valueID = $this->uri->segment('4'); $quesID = $this->uri->segment('5'); 
		if ($quesID){
			$this->db->where('id', $quesID)->update('lquestion', array('status' => 0));
			redirect('control/addproduct/edit_view/'.$valueID.'/removed#stopques');
		}
		
		$query = $this->db->get_where("lca", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "addproduct"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function disable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->addproduct_model->update_record($valueID, array('status' => '0'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 1; $data['page'] = "addproduct"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->addproduct_model->update_record($valueID, array('status' => '1'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 2; $data['page'] = "addproduct"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/addproduct', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* change enable and disable status start */
	
	public function item_list(){
		$edit = $this->uri->segment('3');
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));
        $b = "ter";
        $total_record = $this->addproduct_model->total_record();
		$categories = $this->addproduct_model->get_record($length, $start);
		
		if($edit="edit_view"){ $b = "ter"; $a = "<i class='fa fa-pencil'></i> edit & supply";}else{$a="";}
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/addproduct/wrong_entry_view/".$r->id."?w=wrong_entry' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'>edit wrong entry</a><br><br>".
			"<a href='index.php/control/addproduct/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'>$a</a><br><br>";
			if ($r->status==1) $links .= "<a href='".site_url('index.php/control/addproduct/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->pname?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('index.php/control/addproduct/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->pname?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div>";
			
			$data[] = array(
                "$status <br><font size=4><b>".$r->pname."</b></font>",
				"<b>".$r->amount."</b>",
				"<b>".$r->total."</b>",
				"<b>".$r->amount2."</b>",
				"<b>".$r->total2."</b>",
				//"".@date('M d, Y',$r->added_date)."",
				"<img src='".$r->imglink."' width='150' height='100'>",
                $links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
