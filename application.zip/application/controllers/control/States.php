<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class States extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('category_model');
		$this->load->model('state_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "mstate";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/states', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function update(){
		$state = $this->uri->segment('4'); $status = $this->uri->segment('5');
		$this->state_model->update_record($state, array('status' => $status));
		if ($status==0) echo "<span class='label label-danger'>deactivated</span>";
		else echo "<span class='label label-success'>activated</span>";
	}
	
}
