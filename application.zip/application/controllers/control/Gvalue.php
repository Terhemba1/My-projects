<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gvalue extends CI_Controller {
	
	function __construct() { 
        parent::__construct();
		$this->load->model('settings_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('gvalue_model');
		$this->load->helper("all_functions");
    }
	  
	public function index(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "gvalue"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	/* add new category start */
	public function add_view(){
		$data = array();
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['page'] = "gvalue"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function add_process(){
		$this->form_validation->set_rules('value', 'value', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['error'] = 1; }
		else{
			$query = $this->db->get_where('value', array('value' => $this->input->post('value'), 'type' => 'Generic'));
			$result['category'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 2; }
			else{
				$datainsert = array(
					'type' => 'Generic',
					'organization' => '',
					'value' => $this->input->post('value'),
					'datetime' => @time(),
					'status' => 1
				);
				
				$last_id = $this->gvalue_model->insert_record($datainsert);
				redirect('control/gvalue/edit_view/'.$last_id.'/new');
			}
		}
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "gvalue"; $data['whattodo'] = "add";
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function question(){
		$data = array(); $data = array(); $valueID = $this->uri->segment('4');
		$this->form_validation->set_rules('question', 'question', 'required');
		$this->form_validation->set_rules('qtype', 'qtype', 'required');
		
		$data = array();
		if ($this->form_validation->run() == FALSE) { $data['errorT'] = 1; }
		else{
			$good = "yes"; $scale = "";
			if ($this->input->post('qtype') == 'Likert Scale'){ 
				if ($this->input->post('qscale')){  
					$brkscale = @explode(',', $this->input->post('qscale'));
					if (count($brkscale) > 1){ $scale = $this->input->post('qscale'); }else{ $good = "no"; }
				}else{ $good = "no"; }
			}
			if ($good == 'no') { $data['errorT'] = 5; }
			else{
				$query = $this->db->get_where('question', array('status' => 1, 'value' => $valueID, 'type' => $this->input->post('qtype'), 'question' => $this->input->post('question')));
				//$result['question'] = $query->result();
				if ($query->num_rows() > 0){ $data['errorT'] = 2; }
				else{
					$query = $this->db->get_where('question', array('value' => $valueID)); $numhave = $query->num_rows()+1;
					$datainsert = array(
						'value' => $valueID,
						'type' => $this->input->post('qtype'),
						'question' => $this->input->post('question'),
						'scale' => $scale,
						'arrange' => $numhave,
						'status' => 1
					);
					
					$this->db->insert('question', $datainsert);
					redirect('control/gvalue/edit_view/'.$valueID.'/qnew#stopques');
				}
			}
		}
		
		$query = $this->db->get_where("value", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "gvalue"; $data['whattodo'] = "edit"; $data['error'] = 0;
			
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* add new category end */
	
	/* edit new category start */
	public function edit_view(){
		$data = array();
		$valueID = $this->uri->segment('4'); $newstatus = $this->uri->segment('5');
		$query = $this->db->get_where("value", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		if ($newstatus == 'new'){ $data['error'] = 1; }elseif ($newstatus == 'qnew'){ $data['errorT'] = 3; $data['error'] = 0; }
		elseif ($newstatus == 'removed'){ $data['errorT'] = 4; $data['error'] = 0; }else{ $data['error'] = 0; }
		$data['page'] = "gvalue"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function edit_process(){
		$data = array(); $data = array(); $valueID = $this->uri->segment('4'); 
		$this->form_validation->set_rules('value', 'value', 'required');
		
		if ($this->form_validation->run() == FALSE){ $data['error'] = 4; }
		else{
			$query = $this->db->get_where('value', array('id !=' => $valueID, 'value' => $this->input->post('value'), 'type' => 'Generic'));
			//$result['category'] = $query->result();
			if ($query->num_rows() > 0){ $data['error'] = 5; }
			else{
				$datainsert = array('value' => $this->input->post('value'));
				
				$this->gvalue_model->update_record($valueID, $datainsert);
				$data['error'] = 7;
				
			}
		}
		
		$query = $this->db->get_where("value", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "gvalue"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function arrange(){
		$data = array(); $valueID = $this->uri->segment('4'); 
		if ($this->input->get('q')){
			if ($this->input->get('up')){
				$query = $this->db->order_by('arrange', 'desc')->get_where('question', array('status' => 1, 'value' => $valueID, 'arrange<' => $this->input->get('up'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('question', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('question', array('arrange' => $this->input->get('up')));
			
			}elseif($this->input->get('down')){
				$query = $this->db->order_by('arrange', 'asc')->get_where('question', array('status' => 1, 'value' => $valueID, 'arrange>' => $this->input->get('down'))); 
				$result['q1'] = $query->result();
				$this->db->where('id', $this->input->get('q'))->update('question', array('arrange' => $result['q1'][0]->arrange));
				$this->db->where('id', $result['q1'][0]->id)->update('question', array('arrange' => $this->input->get('down')));
				
			}
			redirect('control/gvalue/edit_view/'.$valueID.'#stopques');
		}
		
		$query = $this->db->get_where("value", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "gvalue"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* edit new category end */
	
	/* change enable and disable status start */
	
	public function remove(){
		$data = array(); $valueID = $this->uri->segment('4'); $quesID = $this->uri->segment('5'); 
		if ($quesID){
			$this->db->where('id', $quesID)->update('question', array('status' => 0));
			redirect('control/gvalue/edit_view/'.$valueID.'/removed#stopques');
		}
		
		$query = $this->db->get_where("value", array("id"=>$valueID)); $data['records'] = $query->row();
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['page'] = "gvalue"; $data['whattodo'] = "edit";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	public function disable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->gvalue_model->update_record($valueID, array('status' => '0'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 1; $data['page'] = "gvalue"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	public function enable_process(){
		$data = array();
		$valueID = $this->uri->segment('4');
		$this->gvalue_model->update_record($valueID, array('status' => '1'));
		
		$data['settings'] = $this->settings_model->getSettings();
		$data['error'] = 0; $data['ADerror'] = 2; $data['page'] = "gvalue"; $data['whattodo'] = "add";
		
		$this->load->view('control/p_header', $data);
		$this->load->view('control/gvalue', $data);
		$this->load->view('control/p_footer', $data);
	}
	
	/* change enable and disable status start */
	
	public function item_list(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));

        $total_record = $this->gvalue_model->total_record();
		$categories = $this->gvalue_model->get_record($length, $start);
		
		$data = array();
        foreach($categories->result() as $r) {
			if ($r->status==1){ $status = "<span class='label label-success'>active</span>"; }else{ $status = "<span class='label label-warning'>disabled</span>"; }
			
			$links = "";
			$links = "<div class='btn-group'>".
			"<a href='index.php/control/gvalue/edit_view/".$r->id."' data-toggle='tooltip' title='Edit' class='btn btn-xs btn-default'><i class='fa fa-pencil'></i> edit</a>";
			if ($r->status==1) $links .= "<a href='".site_url('index.php/control/gvalue/disable_process/'.$r->id)."' class='btn btn-xs btn-danger' onClick='javascript:return confirm(\"Are sure you want to disable $r->value?\")'><i class='fa fa-times'></i> deactivate</a>";
			else $links .= "<a href='".site_url('index.php/control/gvalue/enable_process/'.$r->id)."' class='btn btn-xs btn-success' onClick='javascript:return confirm(\"Are sure you want to activate $r->value?\")'><i class='fa fa-check'></i> activate</a>";
			$links .= "</div>";
			
			$data[] = array(
                "$status <br><font size=4><b>".$r->value."</b></font>",
                $links
            );
        }
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $total_record,
            "recordsFiltered" => $total_record,
            "data" => $data
        );
        echo json_encode($output);
        exit();
	}
	
}
